# ✅ AnnadataHub — Developer Checklist

## Before Starting
☐ Received ZIP file from owner
☐ Received Claude AI API key from owner
☐ Received GoDaddy domain name from owner

## Deployment
☐ MongoDB Atlas cluster created
☐ Backend deployed on Render.com
☐ Frontend deployed on Vercel.com
☐ GoDaddy domain connected

## Pages Live
☐ Homepage loads → www.domain.com
☐ Pricing page → www.domain.com/pricing.html
☐ Legal page → www.domain.com/legal.html

## Testing Done
☐ Register new account works
☐ Login works
☐ Crop photo upload works
☐ AI gives disease result
☐ Works on mobile phone

## Final
☐ Legal page updated with owner's WhatsApp number
☐ Legal page updated with owner's city
☐ All links working
☐ Handed over to owner ✅
