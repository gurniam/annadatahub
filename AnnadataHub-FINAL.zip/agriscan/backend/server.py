from fastapi import FastAPI, APIRouter, HTTPException, Depends, Request, Header, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
import re
import html
from pathlib import Path
from pydantic import BaseModel, Field, EmailStr, validator
from typing import List, Optional, Dict
import uuid
from datetime import datetime, timezone, timedelta
import jwt
import bcrypt
import base64
import hashlib
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# ===================== SECURITY CONFIGURATION =====================

# Rate Limiter
limiter = Limiter(key_func=get_remote_address)

# Security Settings
MAX_LOGIN_ATTEMPTS = 5
LOCKOUT_DURATION_MINUTES = 15
PASSWORD_MIN_LENGTH = 8
PASSWORD_REQUIRE_SPECIAL = True
PASSWORD_REQUIRE_NUMBER = True
SESSION_TIMEOUT_HOURS = 24

# Blocked IPs cache (in production, use Redis)
blocked_ips: Dict[str, datetime] = {}
failed_login_attempts: Dict[str, Dict] = {}

# MongoDB connection
mongo_url = os.environ.get('MONGO_URL', 'mongodb://localhost:27017')
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ.get('DB_NAME', 'test_database')]

# JWT Settings
JWT_SECRET = os.environ.get('JWT_SECRET_KEY', 'agriscan-secret-key')
JWT_ALGORITHM = "HS256"
JWT_EXPIRATION_HOURS = SESSION_TIMEOUT_HOURS

# Create the main app with security settings
app = FastAPI(
    title="AgriScan AI API",
    docs_url=None,  # Disable docs in production
    redoc_url=None,  # Disable redoc in production
    openapi_url=None  # Disable openapi schema
)
api_router = APIRouter(prefix="/api")
security = HTTPBearer()

# Add rate limiter to app
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

# Configure logging (don't log sensitive data)
logging.basicConfig(
    level=logging.INFO, 
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# ===================== SECURITY HELPERS =====================

def sanitize_input(text: str) -> str:
    """Sanitize user input to prevent XSS and injection attacks"""
    if not text:
        return text
    # HTML escape
    text = html.escape(text)
    # Remove potential NoSQL injection patterns
    dangerous_patterns = ['$', '{', '}', '[', ']']
    for pattern in dangerous_patterns:
        text = text.replace(pattern, '')
    return text.strip()

def validate_password_strength(password: str) -> tuple[bool, str]:
    """Check password meets security requirements"""
    if len(password) < PASSWORD_MIN_LENGTH:
        return False, f"Password must be at least {PASSWORD_MIN_LENGTH} characters"
    if PASSWORD_REQUIRE_NUMBER and not re.search(r'\d', password):
        return False, "Password must contain at least one number"
    if PASSWORD_REQUIRE_SPECIAL and not re.search(r'[!@#$%^&*(),.?":{}|<>]', password):
        return False, "Password must contain at least one special character"
    if not re.search(r'[A-Z]', password):
        return False, "Password must contain at least one uppercase letter"
    if not re.search(r'[a-z]', password):
        return False, "Password must contain at least one lowercase letter"
    return True, "Password is strong"

def check_rate_limit(ip: str, action: str = "login") -> bool:
    """Check if IP is rate limited"""
    if ip in blocked_ips:
        if datetime.now(timezone.utc) < blocked_ips[ip]:
            return False
        else:
            del blocked_ips[ip]
    return True

def record_failed_attempt(ip: str, email: str):
    """Record failed login attempt"""
    key = f"{ip}:{email}"
    if key not in failed_login_attempts:
        failed_login_attempts[key] = {"count": 0, "first_attempt": datetime.now(timezone.utc)}
    
    failed_login_attempts[key]["count"] += 1
    
    if failed_login_attempts[key]["count"] >= MAX_LOGIN_ATTEMPTS:
        blocked_ips[ip] = datetime.now(timezone.utc) + timedelta(minutes=LOCKOUT_DURATION_MINUTES)
        logger.warning(f"IP {ip} blocked for {LOCKOUT_DURATION_MINUTES} minutes due to failed login attempts")

def clear_failed_attempts(ip: str, email: str):
    """Clear failed attempts after successful login"""
    key = f"{ip}:{email}"
    if key in failed_login_attempts:
        del failed_login_attempts[key]

def hash_sensitive_data(data: str) -> str:
    """Hash sensitive data for logging"""
    return hashlib.sha256(data.encode()).hexdigest()[:8]

# ===================== MODELS =====================

class UserCreate(BaseModel):
    email: EmailStr
    password: str
    name: str
    
    @validator('name')
    def validate_name(cls, v):
        if not v or len(v.strip()) < 2:
            raise ValueError('Name must be at least 2 characters')
        if len(v) > 100:
            raise ValueError('Name must be less than 100 characters')
        return sanitize_input(v)
    
    @validator('password')
    def validate_password(cls, v):
        is_valid, message = validate_password_strength(v)
        if not is_valid:
            raise ValueError(message)
        return v

class UserLogin(BaseModel):
    email: EmailStr
    password: str

class UserResponse(BaseModel):
    id: str
    email: str
    name: str
    subscription_tier: str = "free"
    scans_this_month: int = 0
    created_at: str

class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserResponse

class AnalysisRequest(BaseModel):
    image_base64: str
    crop_type: Optional[str] = None

class AnalysisResult(BaseModel):
    id: str
    user_id: str
    disease_name: str
    confidence: float
    description: str
    treatment: str
    prevention: str
    severity: str
    crop_type: str
    image_url: Optional[str] = None
    created_at: str

class HistoryItem(BaseModel):
    id: str
    disease_name: str
    severity: str
    crop_type: str
    confidence: float
    created_at: str

class CommunityPostCreate(BaseModel):
    title: str
    content: str
    image_base64: Optional[str] = None
    tags: List[str] = []

class CommunityPost(BaseModel):
    id: str
    user_id: str
    user_name: str
    title: str
    content: str
    image_url: Optional[str] = None
    tags: List[str] = []
    likes: int = 0
    comments_count: int = 0
    created_at: str

class CommentCreate(BaseModel):
    content: str

class Comment(BaseModel):
    id: str
    post_id: str
    user_id: str
    user_name: str
    content: str
    created_at: str

class SubscriptionRequest(BaseModel):
    origin_url: str

class HealthDataPoint(BaseModel):
    date: str
    score: float
    scans: int

# ===================== NEW FEATURE MODELS =====================

# Supported Languages
SUPPORTED_LANGUAGES = {
    "en": "English",
    "hi": "Hindi (हिंदी)",
    "bn": "Bengali (বাংলা)",
    "te": "Telugu (తెలుగు)",
    "mr": "Marathi (मराठी)",
    "ta": "Tamil (தமிழ்)",
    "gu": "Gujarati (ગુજરાતી)",
    "kn": "Kannada (ಕನ್ನಡ)",
    "ml": "Malayalam (മലയാളം)",
    "pa": "Punjabi (ਪੰਜਾਬੀ)",
    "or": "Odia (ଓଡ଼ିଆ)",
    "as": "Assamese (অসমীয়া)",
    "ur": "Urdu (اردو)"
}

class PersonalizedAdviceRequest(BaseModel):
    crop_type: str
    region: Optional[str] = None
    language: str = "en"
    growth_stage: Optional[str] = None
    soil_type: Optional[str] = None
    weather_conditions: Optional[str] = None

class PersonalizedAdvice(BaseModel):
    id: str
    user_id: str
    crop_type: str
    language: str
    advice: str
    tips: List[str]
    weather_alert: Optional[str] = None
    market_info: Optional[str] = None
    created_at: str

class PostHarvestRequest(BaseModel):
    crop_type: str
    harvest_date: Optional[str] = None
    storage_conditions: Optional[str] = None
    quantity: Optional[str] = None
    language: str = "en"

class PostHarvestAdvice(BaseModel):
    id: str
    user_id: str
    crop_type: str
    storage_tips: List[str]
    handling_guidelines: List[str]
    optimal_conditions: dict
    loss_prevention_tips: List[str]
    market_timing: str
    shelf_life: str
    language: str
    created_at: str

class PestAlertCreate(BaseModel):
    pest_name: str
    crop_affected: str
    severity: str  # low, medium, high, critical
    location: str
    latitude: Optional[float] = None
    longitude: Optional[float] = None
    description: str
    image_base64: Optional[str] = None

class PestAlert(BaseModel):
    id: str
    user_id: str
    user_name: str
    pest_name: str
    crop_affected: str
    severity: str
    location: str
    latitude: Optional[float] = None
    longitude: Optional[float] = None
    description: str
    verified: bool = False
    reports_count: int = 1
    created_at: str

class EarlyWarning(BaseModel):
    id: str
    alert_type: str  # pest, disease, weather
    title: str
    description: str
    affected_crops: List[str]
    affected_regions: List[str]
    severity: str
    prevention_tips: List[str]
    active: bool = True
    created_at: str

# ===================== AUTH HELPERS =====================

def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')

def verify_password(password: str, hashed: str) -> bool:
    return bcrypt.checkpw(password.encode('utf-8'), hashed.encode('utf-8'))

def create_token(user_id: str) -> str:
    payload = {
        "sub": user_id,
        "exp": datetime.now(timezone.utc) + timedelta(hours=JWT_EXPIRATION_HOURS),
        "iat": datetime.now(timezone.utc)
    }
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)

async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)) -> dict:
    try:
        payload = jwt.decode(credentials.credentials, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        user_id = payload.get("sub")
        if not user_id:
            raise HTTPException(status_code=401, detail="Invalid token")
        user = await db.users.find_one({"id": user_id}, {"_id": 0, "password": 0})
        if not user:
            raise HTTPException(status_code=401, detail="User not found")
        return user
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expired")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token")

# ===================== AUTH ROUTES =====================

@api_router.post("/auth/register", response_model=TokenResponse)
@limiter.limit("5/minute")
async def register(request: Request, user_data: UserCreate):
    """Register new user with rate limiting and security checks"""
    client_ip = get_remote_address(request)
    
    # Check if IP is blocked
    if not check_rate_limit(client_ip, "register"):
        logger.warning(f"Blocked registration attempt from IP: {hash_sensitive_data(client_ip)}")
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail=f"Too many attempts. Please try again in {LOCKOUT_DURATION_MINUTES} minutes."
        )
    
    # Check if email already exists
    existing = await db.users.find_one({"email": user_data.email.lower()})
    if existing:
        raise HTTPException(status_code=400, detail="Email already registered")
    
    user_id = str(uuid.uuid4())
    user = {
        "id": user_id,
        "email": user_data.email.lower(),  # Store lowercase
        "name": sanitize_input(user_data.name),
        "password": hash_password(user_data.password),
        "subscription_tier": "free",
        "scans_this_month": 0,
        "month_reset": datetime.now(timezone.utc).strftime("%Y-%m"),
        "created_at": datetime.now(timezone.utc).isoformat(),
        "last_login": datetime.now(timezone.utc).isoformat(),
        "login_count": 1,
        "security_version": 1  # For future password policy updates
    }
    await db.users.insert_one(user)
    
    logger.info(f"New user registered: {hash_sensitive_data(user_data.email)}")
    
    token = create_token(user_id)
    user_response = UserResponse(
        id=user_id, email=user["email"], name=user["name"],
        subscription_tier=user["subscription_tier"],
        scans_this_month=user["scans_this_month"],
        created_at=user["created_at"]
    )
    return TokenResponse(access_token=token, user=user_response)

@api_router.post("/auth/login", response_model=TokenResponse)
@limiter.limit("10/minute")
async def login(request: Request, credentials: UserLogin):
    """Login with rate limiting and brute force protection"""
    client_ip = get_remote_address(request)
    email_lower = credentials.email.lower()
    
    # Check if IP is blocked
    if not check_rate_limit(client_ip, "login"):
        logger.warning(f"Blocked login attempt from IP: {hash_sensitive_data(client_ip)}")
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail=f"Account temporarily locked. Please try again in {LOCKOUT_DURATION_MINUTES} minutes."
        )
    
    user = await db.users.find_one({"email": email_lower})
    
    if not user or not verify_password(credentials.password, user["password"]):
        # Record failed attempt
        record_failed_attempt(client_ip, email_lower)
        logger.warning(f"Failed login attempt for: {hash_sensitive_data(email_lower)} from IP: {hash_sensitive_data(client_ip)}")
        # Use generic message to prevent email enumeration
        raise HTTPException(status_code=401, detail="Invalid email or password")
    
    # Clear failed attempts on successful login
    clear_failed_attempts(client_ip, email_lower)
    
    # Update last login
    await db.users.update_one(
        {"id": user["id"]},
        {"$set": {"last_login": datetime.now(timezone.utc).isoformat()}, "$inc": {"login_count": 1}}
    )
    
    logger.info(f"Successful login: {hash_sensitive_data(email_lower)}")
    
    token = create_token(user["id"])
    user_response = UserResponse(
        id=user["id"], email=user["email"], name=user["name"],
        subscription_tier=user.get("subscription_tier", "free"),
        scans_this_month=user.get("scans_this_month", 0),
        created_at=user["created_at"]
    )
    return TokenResponse(access_token=token, user=user_response)

@api_router.get("/auth/me", response_model=UserResponse)
@limiter.limit("30/minute")
async def get_me(request: Request, user: dict = Depends(get_current_user)):
    return UserResponse(**user)

# ===================== DISEASE ANALYSIS =====================

async def analyze_crop_image(image_base64: str, crop_type: Optional[str] = None) -> dict:
    """Analyze crop image using OpenAI GPT-5.2 Vision"""
    from emergentintegrations.llm.chat import LlmChat, UserMessage, ImageContent
    
    api_key = os.environ.get('EMERGENT_LLM_KEY')
    if not api_key:
        raise HTTPException(status_code=500, detail="LLM API key not configured")
    
    chat = LlmChat(
        api_key=api_key,
        session_id=str(uuid.uuid4()),
        system_message="""You are an expert agricultural pathologist and crop disease specialist. 
        Analyze the crop image and provide a detailed diagnosis in JSON format with these exact fields:
        {
            "disease_name": "Name of the disease or 'Healthy' if no disease",
            "confidence": 0.0-1.0 confidence score,
            "description": "Detailed description of the condition",
            "treatment": "Recommended treatment steps",
            "prevention": "Prevention tips for future",
            "severity": "healthy/mild/moderate/severe/critical",
            "crop_type": "Identified crop type"
        }
        Always respond with valid JSON only."""
    ).with_model("anthropic", "claude-sonnet-4-5-20250929")
    
    crop_context = f" The user indicates this is a {crop_type} crop." if crop_type else ""
    
    image_content = ImageContent(image_base64=image_base64)
    user_message = UserMessage(
        text=f"Analyze this crop image for any diseases or health issues.{crop_context} Provide diagnosis in JSON format.",
        file_contents=[image_content]
    )
    
    response = await chat.send_message(user_message)
    
    import json
    try:
        # Extract JSON from response
        response_text = response.strip()
        if response_text.startswith("```"):
            lines = response_text.split("\n")
            json_lines = []
            in_json = False
            for line in lines:
                if line.startswith("```json"):
                    in_json = True
                    continue
                elif line.startswith("```"):
                    in_json = False
                    continue
                if in_json:
                    json_lines.append(line)
            response_text = "\n".join(json_lines)
        
        result = json.loads(response_text)
        return result
    except json.JSONDecodeError:
        # Fallback parsing
        return {
            "disease_name": "Analysis Error",
            "confidence": 0.0,
            "description": response[:500] if response else "Could not analyze image",
            "treatment": "Please try again with a clearer image",
            "prevention": "Ensure good image quality",
            "severity": "unknown",
            "crop_type": crop_type or "Unknown"
        }

@api_router.post("/analyze", response_model=AnalysisResult)
@limiter.limit("20/minute")
async def analyze_crop(request: Request, analysis_request: AnalysisRequest, user: dict = Depends(get_current_user)):
    """Analyze crop image with rate limiting"""
    # Check subscription limits
    current_month = datetime.now(timezone.utc).strftime("%Y-%m")
    user_doc = await db.users.find_one({"id": user["id"]})
    
    # Reset monthly counter if new month
    if user_doc.get("month_reset") != current_month:
        await db.users.update_one(
            {"id": user["id"]},
            {"$set": {"scans_this_month": 0, "month_reset": current_month}}
        )
        user_doc["scans_this_month"] = 0
    
    # Check limits for free tier
    if user_doc.get("subscription_tier", "free") == "free" and user_doc.get("scans_this_month", 0) >= 5:
        raise HTTPException(status_code=403, detail="Free tier limit reached. Upgrade to Premium for unlimited scans.")
    
    # Validate image data
    if not analysis_request.image_base64 or len(analysis_request.image_base64) < 100:
        raise HTTPException(status_code=400, detail="Invalid image data")
    
    # Limit image size (max 10MB base64)
    if len(analysis_request.image_base64) > 10 * 1024 * 1024 * 1.37:  # Base64 is ~37% larger
        raise HTTPException(status_code=400, detail="Image too large. Max size is 10MB")
    
    # Analyze the image
    result = await analyze_crop_image(analysis_request.image_base64, analysis_request.crop_type)
    
    analysis_id = str(uuid.uuid4())
    analysis = {
        "id": analysis_id,
        "user_id": user["id"],
        "disease_name": sanitize_input(result.get("disease_name", "Unknown")),
        "confidence": min(max(float(result.get("confidence", 0.0)), 0.0), 1.0),  # Clamp 0-1
        "description": sanitize_input(result.get("description", "")),
        "treatment": sanitize_input(result.get("treatment", "")),
        "prevention": sanitize_input(result.get("prevention", "")),
        "severity": sanitize_input(result.get("severity", "unknown")),
        "crop_type": sanitize_input(result.get("crop_type", analysis_request.crop_type or "Unknown")),
        "created_at": datetime.now(timezone.utc).isoformat()
    }
    
    await db.analyses.insert_one(analysis)
    
    # Increment scan count
    await db.users.update_one(
        {"id": user["id"]},
        {"$inc": {"scans_this_month": 1}}
    )
    
    return AnalysisResult(**analysis)

@api_router.get("/analysis/{analysis_id}", response_model=AnalysisResult)
async def get_analysis(analysis_id: str, user: dict = Depends(get_current_user)):
    analysis = await db.analyses.find_one({"id": analysis_id, "user_id": user["id"]}, {"_id": 0})
    if not analysis:
        raise HTTPException(status_code=404, detail="Analysis not found")
    return AnalysisResult(**analysis)

# ===================== HISTORY =====================

@api_router.get("/history", response_model=List[HistoryItem])
async def get_history(user: dict = Depends(get_current_user), limit: int = 50):
    analyses = await db.analyses.find(
        {"user_id": user["id"]},
        {"_id": 0, "id": 1, "disease_name": 1, "severity": 1, "crop_type": 1, "confidence": 1, "created_at": 1}
    ).sort("created_at", -1).limit(limit).to_list(limit)
    return [HistoryItem(**a) for a in analyses]

@api_router.delete("/history/{analysis_id}")
async def delete_analysis(analysis_id: str, user: dict = Depends(get_current_user)):
    result = await db.analyses.delete_one({"id": analysis_id, "user_id": user["id"]})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Analysis not found")
    return {"message": "Deleted successfully"}

# ===================== HEALTH MONITORING =====================

@api_router.get("/health-data", response_model=List[HealthDataPoint])
async def get_health_data(user: dict = Depends(get_current_user), days: int = 30):
    from_date = datetime.now(timezone.utc) - timedelta(days=days)
    
    pipeline = [
        {"$match": {"user_id": user["id"], "created_at": {"$gte": from_date.isoformat()}}},
        {"$addFields": {"date": {"$substr": ["$created_at", 0, 10]}}},
        {"$group": {
            "_id": "$date",
            "avg_confidence": {"$avg": "$confidence"},
            "scans": {"$sum": 1},
            "healthy_count": {"$sum": {"$cond": [{"$eq": ["$severity", "healthy"]}, 1, 0]}}
        }},
        {"$sort": {"_id": 1}}
    ]
    
    results = await db.analyses.aggregate(pipeline).to_list(100)
    
    data = []
    for r in results:
        total = r["scans"]
        healthy = r["healthy_count"]
        score = (healthy / total * 100) if total > 0 else 0
        data.append(HealthDataPoint(date=r["_id"], score=round(score, 1), scans=total))
    
    return data

# ===================== COMMUNITY FORUM =====================

@api_router.post("/community/posts", response_model=CommunityPost)
async def create_post(post: CommunityPostCreate, user: dict = Depends(get_current_user)):
    post_id = str(uuid.uuid4())
    post_doc = {
        "id": post_id,
        "user_id": user["id"],
        "user_name": user["name"],
        "title": post.title,
        "content": post.content,
        "image_url": None,
        "tags": post.tags,
        "likes": 0,
        "liked_by": [],
        "comments_count": 0,
        "created_at": datetime.now(timezone.utc).isoformat()
    }
    await db.community_posts.insert_one(post_doc)
    return CommunityPost(**post_doc)

@api_router.get("/community/posts", response_model=List[CommunityPost])
async def get_posts(limit: int = 20, skip: int = 0, tag: Optional[str] = None):
    query = {}
    if tag:
        query["tags"] = tag
    
    posts = await db.community_posts.find(query, {"_id": 0, "liked_by": 0}).sort("created_at", -1).skip(skip).limit(limit).to_list(limit)
    return [CommunityPost(**p) for p in posts]

@api_router.get("/community/posts/{post_id}", response_model=CommunityPost)
async def get_post(post_id: str):
    post = await db.community_posts.find_one({"id": post_id}, {"_id": 0, "liked_by": 0})
    if not post:
        raise HTTPException(status_code=404, detail="Post not found")
    return CommunityPost(**post)

@api_router.post("/community/posts/{post_id}/like")
async def like_post(post_id: str, user: dict = Depends(get_current_user)):
    post = await db.community_posts.find_one({"id": post_id})
    if not post:
        raise HTTPException(status_code=404, detail="Post not found")
    
    liked_by = post.get("liked_by", [])
    if user["id"] in liked_by:
        # Unlike
        await db.community_posts.update_one(
            {"id": post_id},
            {"$pull": {"liked_by": user["id"]}, "$inc": {"likes": -1}}
        )
        return {"liked": False}
    else:
        # Like
        await db.community_posts.update_one(
            {"id": post_id},
            {"$push": {"liked_by": user["id"]}, "$inc": {"likes": 1}}
        )
        return {"liked": True}

@api_router.post("/community/posts/{post_id}/comments", response_model=Comment)
async def create_comment(post_id: str, comment: CommentCreate, user: dict = Depends(get_current_user)):
    post = await db.community_posts.find_one({"id": post_id})
    if not post:
        raise HTTPException(status_code=404, detail="Post not found")
    
    comment_id = str(uuid.uuid4())
    comment_doc = {
        "id": comment_id,
        "post_id": post_id,
        "user_id": user["id"],
        "user_name": user["name"],
        "content": comment.content,
        "created_at": datetime.now(timezone.utc).isoformat()
    }
    await db.comments.insert_one(comment_doc)
    await db.community_posts.update_one({"id": post_id}, {"$inc": {"comments_count": 1}})
    
    return Comment(**comment_doc)

@api_router.get("/community/posts/{post_id}/comments", response_model=List[Comment])
async def get_comments(post_id: str, limit: int = 50):
    comments = await db.comments.find({"post_id": post_id}, {"_id": 0}).sort("created_at", 1).to_list(limit)
    return [Comment(**c) for c in comments]

# ===================== SUBSCRIPTIONS =====================

SUBSCRIPTION_PACKAGES = {
    "premium_monthly": {
        "name": "Premium Monthly",
        "amount": 9.99,
        "currency": "usd",
        "tier": "premium"
    }
}

@api_router.post("/subscription/checkout")
async def create_checkout(request: SubscriptionRequest, req: Request, user: dict = Depends(get_current_user)):
    from emergentintegrations.payments.stripe.checkout import StripeCheckout, CheckoutSessionRequest
    
    api_key = os.environ.get('STRIPE_API_KEY')
    if not api_key:
        raise HTTPException(status_code=500, detail="Stripe not configured")
    
    host_url = str(req.base_url).rstrip('/')
    webhook_url = f"{host_url}/api/webhook/stripe"
    
    stripe_checkout = StripeCheckout(api_key=api_key, webhook_url=webhook_url)
    
    package = SUBSCRIPTION_PACKAGES["premium_monthly"]
    success_url = f"{request.origin_url}/subscription/success?session_id={{CHECKOUT_SESSION_ID}}"
    cancel_url = f"{request.origin_url}/pricing"
    
    checkout_request = CheckoutSessionRequest(
        amount=package["amount"],
        currency=package["currency"],
        success_url=success_url,
        cancel_url=cancel_url,
        metadata={
            "user_id": user["id"],
            "package": "premium_monthly",
            "tier": "premium"
        }
    )
    
    session = await stripe_checkout.create_checkout_session(checkout_request)
    
    # Record transaction
    transaction = {
        "id": str(uuid.uuid4()),
        "session_id": session.session_id,
        "user_id": user["id"],
        "amount": package["amount"],
        "currency": package["currency"],
        "package": "premium_monthly",
        "payment_status": "pending",
        "created_at": datetime.now(timezone.utc).isoformat()
    }
    await db.payment_transactions.insert_one(transaction)
    
    return {"url": session.url, "session_id": session.session_id}

@api_router.get("/subscription/status/{session_id}")
async def get_checkout_status(session_id: str, user: dict = Depends(get_current_user)):
    from emergentintegrations.payments.stripe.checkout import StripeCheckout
    
    api_key = os.environ.get('STRIPE_API_KEY')
    stripe_checkout = StripeCheckout(api_key=api_key, webhook_url="")
    
    status = await stripe_checkout.get_checkout_status(session_id)
    
    # Update transaction and user subscription if paid
    if status.payment_status == "paid":
        transaction = await db.payment_transactions.find_one({"session_id": session_id})
        if transaction and transaction.get("payment_status") != "paid":
            await db.payment_transactions.update_one(
                {"session_id": session_id},
                {"$set": {"payment_status": "paid", "paid_at": datetime.now(timezone.utc).isoformat()}}
            )
            # Upgrade user subscription
            await db.users.update_one(
                {"id": user["id"]},
                {"$set": {"subscription_tier": "premium"}}
            )
    
    return {
        "status": status.status,
        "payment_status": status.payment_status,
        "amount_total": status.amount_total,
        "currency": status.currency
    }

@api_router.post("/webhook/stripe")
async def stripe_webhook(request: Request):
    from emergentintegrations.payments.stripe.checkout import StripeCheckout
    
    api_key = os.environ.get('STRIPE_API_KEY')
    stripe_checkout = StripeCheckout(api_key=api_key, webhook_url="")
    
    body = await request.body()
    signature = request.headers.get("Stripe-Signature", "")
    
    try:
        event = await stripe_checkout.handle_webhook(body, signature)
        
        if event.payment_status == "paid":
            transaction = await db.payment_transactions.find_one({"session_id": event.session_id})
            if transaction and transaction.get("payment_status") != "paid":
                await db.payment_transactions.update_one(
                    {"session_id": event.session_id},
                    {"$set": {"payment_status": "paid", "paid_at": datetime.now(timezone.utc).isoformat()}}
                )
                user_id = event.metadata.get("user_id")
                if user_id:
                    await db.users.update_one(
                        {"id": user_id},
                        {"$set": {"subscription_tier": "premium"}}
                    )
        
        return {"received": True}
    except Exception as e:
        logger.error(f"Webhook error: {e}")
        return {"received": True}

# ===================== STATS =====================

@api_router.get("/stats")
async def get_user_stats(user: dict = Depends(get_current_user)):
    total_scans = await db.analyses.count_documents({"user_id": user["id"]})
    
    # Count by severity
    severity_pipeline = [
        {"$match": {"user_id": user["id"]}},
        {"$group": {"_id": "$severity", "count": {"$sum": 1}}}
    ]
    severity_results = await db.analyses.aggregate(severity_pipeline).to_list(10)
    severity_counts = {r["_id"]: r["count"] for r in severity_results}
    
    # Get current month scans
    user_doc = await db.users.find_one({"id": user["id"]}, {"_id": 0})
    scans_this_month = user_doc.get("scans_this_month", 0)
    subscription_tier = user_doc.get("subscription_tier", "free")
    
    scan_limit = 5 if subscription_tier == "free" else -1  # -1 means unlimited
    
    return {
        "total_scans": total_scans,
        "scans_this_month": scans_this_month,
        "scan_limit": scan_limit,
        "subscription_tier": subscription_tier,
        "severity_breakdown": severity_counts
    }

# ===================== ROOT =====================

@api_router.get("/")
async def root():
    return {"message": "AgriScan AI API", "version": "1.0.0"}

# ===================== PERSONALIZED CROP ADVICE (12+ Languages) =====================

@api_router.get("/languages")
async def get_languages():
    """Get list of supported languages"""
    return {"languages": SUPPORTED_LANGUAGES}

@api_router.post("/advice/personalized", response_model=PersonalizedAdvice)
async def get_personalized_advice(request: PersonalizedAdviceRequest, user: dict = Depends(get_current_user)):
    """Get hyper-personalized, real-time crop advice in regional language"""
    from emergentintegrations.llm.chat import LlmChat, UserMessage
    
    api_key = os.environ.get('EMERGENT_LLM_KEY')
    if not api_key:
        raise HTTPException(status_code=500, detail="LLM API key not configured")
    
    lang_name = SUPPORTED_LANGUAGES.get(request.language, "English")
    
    chat = LlmChat(
        api_key=api_key,
        session_id=str(uuid.uuid4()),
        system_message=f"""You are an expert agricultural advisor specializing in personalized crop management.
        IMPORTANT: Respond ENTIRELY in {lang_name} language.
        Provide practical, actionable advice based on the farmer's specific conditions.
        Include local practices and indigenous knowledge when relevant.
        Format your response as JSON with these fields:
        {{
            "advice": "Main personalized advice paragraph",
            "tips": ["tip1", "tip2", "tip3", "tip4", "tip5"],
            "weather_alert": "Any weather-related advice or null",
            "market_info": "Current market insights or null"
        }}
        Respond with valid JSON only."""
    ).with_model("anthropic", "claude-sonnet-4-5-20250929")
    
    context_parts = [f"Crop: {request.crop_type}"]
    if request.region:
        context_parts.append(f"Region: {request.region}")
    if request.growth_stage:
        context_parts.append(f"Growth Stage: {request.growth_stage}")
    if request.soil_type:
        context_parts.append(f"Soil Type: {request.soil_type}")
    if request.weather_conditions:
        context_parts.append(f"Weather: {request.weather_conditions}")
    
    context = ", ".join(context_parts)
    
    response = await chat.send_message(UserMessage(
        text=f"Provide personalized farming advice for: {context}. Respond in {lang_name}."
    ))
    
    import json
    try:
        response_text = response.strip()
        if response_text.startswith("```"):
            lines = response_text.split("\n")
            json_lines = [l for l in lines if not l.startswith("```")]
            response_text = "\n".join(json_lines)
        result = json.loads(response_text)
    except:
        result = {
            "advice": response[:1000],
            "tips": [],
            "weather_alert": None,
            "market_info": None
        }
    
    advice_id = str(uuid.uuid4())
    advice_doc = {
        "id": advice_id,
        "user_id": user["id"],
        "crop_type": request.crop_type,
        "language": request.language,
        "advice": result.get("advice", ""),
        "tips": result.get("tips", []),
        "weather_alert": result.get("weather_alert"),
        "market_info": result.get("market_info"),
        "created_at": datetime.now(timezone.utc).isoformat()
    }
    await db.personalized_advice.insert_one(advice_doc)
    
    return PersonalizedAdvice(**advice_doc)

# ===================== POST-HARVEST LOSS PREVENTION =====================

@api_router.post("/postharvest/advice", response_model=PostHarvestAdvice)
async def get_postharvest_advice(request: PostHarvestRequest, user: dict = Depends(get_current_user)):
    """Get post-harvest loss prevention advice"""
    from emergentintegrations.llm.chat import LlmChat, UserMessage
    
    api_key = os.environ.get('EMERGENT_LLM_KEY')
    if not api_key:
        raise HTTPException(status_code=500, detail="LLM API key not configured")
    
    lang_name = SUPPORTED_LANGUAGES.get(request.language, "English")
    
    chat = LlmChat(
        api_key=api_key,
        session_id=str(uuid.uuid4()),
        system_message=f"""You are an expert in post-harvest management and loss prevention.
        IMPORTANT: Respond ENTIRELY in {lang_name} language.
        Provide practical storage, handling, and market timing advice.
        Format your response as JSON:
        {{
            "storage_tips": ["tip1", "tip2", "tip3"],
            "handling_guidelines": ["guideline1", "guideline2", "guideline3"],
            "optimal_conditions": {{"temperature": "X°C", "humidity": "X%", "ventilation": "description"}},
            "loss_prevention_tips": ["tip1", "tip2", "tip3", "tip4"],
            "market_timing": "Best time to sell advice",
            "shelf_life": "Expected shelf life with proper storage"
        }}
        Respond with valid JSON only."""
    ).with_model("anthropic", "claude-sonnet-4-5-20250929")
    
    context_parts = [f"Crop: {request.crop_type}"]
    if request.harvest_date:
        context_parts.append(f"Harvest Date: {request.harvest_date}")
    if request.storage_conditions:
        context_parts.append(f"Current Storage: {request.storage_conditions}")
    if request.quantity:
        context_parts.append(f"Quantity: {request.quantity}")
    
    context = ", ".join(context_parts)
    
    response = await chat.send_message(UserMessage(
        text=f"Provide post-harvest loss prevention advice for: {context}. Respond in {lang_name}."
    ))
    
    import json
    try:
        response_text = response.strip()
        if response_text.startswith("```"):
            lines = response_text.split("\n")
            json_lines = [l for l in lines if not l.startswith("```")]
            response_text = "\n".join(json_lines)
        result = json.loads(response_text)
    except:
        result = {
            "storage_tips": [],
            "handling_guidelines": [],
            "optimal_conditions": {},
            "loss_prevention_tips": [],
            "market_timing": "Unable to determine",
            "shelf_life": "Unable to determine"
        }
    
    advice_id = str(uuid.uuid4())
    advice_doc = {
        "id": advice_id,
        "user_id": user["id"],
        "crop_type": request.crop_type,
        "storage_tips": result.get("storage_tips", []),
        "handling_guidelines": result.get("handling_guidelines", []),
        "optimal_conditions": result.get("optimal_conditions", {}),
        "loss_prevention_tips": result.get("loss_prevention_tips", []),
        "market_timing": result.get("market_timing", ""),
        "shelf_life": result.get("shelf_life", ""),
        "language": request.language,
        "created_at": datetime.now(timezone.utc).isoformat()
    }
    await db.postharvest_advice.insert_one(advice_doc)
    
    return PostHarvestAdvice(**advice_doc)

# ===================== PEST & DISEASE EARLY WARNING NETWORK =====================

@api_router.post("/alerts/report", response_model=PestAlert)
async def report_pest_alert(alert: PestAlertCreate, user: dict = Depends(get_current_user)):
    """Report a pest or disease sighting for the early warning network"""
    alert_id = str(uuid.uuid4())
    alert_doc = {
        "id": alert_id,
        "user_id": user["id"],
        "user_name": user["name"],
        "pest_name": alert.pest_name,
        "crop_affected": alert.crop_affected,
        "severity": alert.severity,
        "location": alert.location,
        "latitude": alert.latitude,
        "longitude": alert.longitude,
        "description": alert.description,
        "verified": False,
        "reports_count": 1,
        "created_at": datetime.now(timezone.utc).isoformat()
    }
    await db.pest_alerts.insert_one(alert_doc)
    
    # Check for similar reports to auto-verify
    similar = await db.pest_alerts.count_documents({
        "pest_name": {"$regex": alert.pest_name, "$options": "i"},
        "location": {"$regex": alert.location.split(",")[0], "$options": "i"},
        "created_at": {"$gte": (datetime.now(timezone.utc) - timedelta(days=7)).isoformat()}
    })
    
    if similar >= 3:
        # Auto-verify if 3+ similar reports
        await db.pest_alerts.update_one({"id": alert_id}, {"$set": {"verified": True}})
        alert_doc["verified"] = True
        
        # Create early warning
        warning = {
            "id": str(uuid.uuid4()),
            "alert_type": "pest",
            "title": f"{alert.pest_name} Alert - {alert.location}",
            "description": f"Multiple reports of {alert.pest_name} affecting {alert.crop_affected} in {alert.location}",
            "affected_crops": [alert.crop_affected],
            "affected_regions": [alert.location],
            "severity": alert.severity,
            "prevention_tips": [
                "Monitor crops regularly for signs of infestation",
                "Implement integrated pest management practices",
                "Consult local agricultural extension services"
            ],
            "active": True,
            "created_at": datetime.now(timezone.utc).isoformat()
        }
        await db.early_warnings.insert_one(warning)
    
    return PestAlert(**alert_doc)

@api_router.get("/alerts/nearby")
async def get_nearby_alerts(location: str, radius_km: int = 50, user: dict = Depends(get_current_user)):
    """Get pest/disease alerts near a location"""
    # Get recent alerts (last 30 days)
    cutoff = (datetime.now(timezone.utc) - timedelta(days=30)).isoformat()
    alerts = await db.pest_alerts.find(
        {
            "location": {"$regex": location.split(",")[0], "$options": "i"},
            "created_at": {"$gte": cutoff}
        },
        {"_id": 0}
    ).sort("created_at", -1).limit(20).to_list(20)
    
    return {"alerts": alerts, "location": location, "radius_km": radius_km}

@api_router.get("/alerts/warnings")
async def get_active_warnings(region: Optional[str] = None):
    """Get active early warnings for a region"""
    query = {"active": True}
    if region:
        query["affected_regions"] = {"$regex": region, "$options": "i"}
    
    warnings = await db.early_warnings.find(query, {"_id": 0}).sort("created_at", -1).limit(10).to_list(10)
    return {"warnings": warnings}

@api_router.get("/alerts/stats")
async def get_alert_stats(user: dict = Depends(get_current_user)):
    """Get statistics about pest/disease alerts"""
    # Total alerts
    total_alerts = await db.pest_alerts.count_documents({})
    
    # Active warnings
    active_warnings = await db.early_warnings.count_documents({"active": True})
    
    # Alerts by severity
    severity_pipeline = [
        {"$group": {"_id": "$severity", "count": {"$sum": 1}}}
    ]
    severity_results = await db.pest_alerts.aggregate(severity_pipeline).to_list(10)
    severity_breakdown = {r["_id"]: r["count"] for r in severity_results}
    
    # Top reported pests
    pest_pipeline = [
        {"$group": {"_id": "$pest_name", "count": {"$sum": 1}}},
        {"$sort": {"count": -1}},
        {"$limit": 5}
    ]
    top_pests = await db.pest_alerts.aggregate(pest_pipeline).to_list(5)
    
    return {
        "total_alerts": total_alerts,
        "active_warnings": active_warnings,
        "severity_breakdown": severity_breakdown,
        "top_reported_pests": [{"name": p["_id"], "count": p["count"]} for p in top_pests]
    }

# Include router and middleware
app.include_router(api_router)

# Security Headers Middleware
@app.middleware("http")
async def add_security_headers(request: Request, call_next):
    response = await call_next(request)
    # Prevent clickjacking
    response.headers["X-Frame-Options"] = "DENY"
    # XSS Protection
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-XSS-Protection"] = "1; mode=block"
    # Referrer Policy
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    # Content Security Policy
    response.headers["Content-Security-Policy"] = "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: https:; font-src 'self' https://fonts.gstatic.com;"
    # Strict Transport Security (HTTPS)
    response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
    # Permissions Policy
    response.headers["Permissions-Policy"] = "camera=(self), microphone=(), geolocation=(self)"
    return response

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get('CORS_ORIGINS', '*').split(','),
    allow_methods=["GET", "POST", "PUT", "DELETE"],  # Restrict methods
    allow_headers=["Authorization", "Content-Type"],  # Restrict headers
)

@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()
