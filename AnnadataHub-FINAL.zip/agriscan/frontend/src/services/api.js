import axios from 'axios';

const API = `${process.env.REACT_APP_BACKEND_URL}/api`;

const getAuthHeaders = () => {
  const token = localStorage.getItem('agriscan_token');
  return token ? { Authorization: `Bearer ${token}` } : {};
};

export const api = {
  // Analysis
  analyzeImage: async (imageBase64, cropType = null) => {
    const response = await axios.post(
      `${API}/analyze`,
      { image_base64: imageBase64, crop_type: cropType },
      { headers: getAuthHeaders() }
    );
    return response.data;
  },

  getAnalysis: async (analysisId) => {
    const response = await axios.get(`${API}/analysis/${analysisId}`, {
      headers: getAuthHeaders()
    });
    return response.data;
  },

  // History
  getHistory: async (limit = 50) => {
    const response = await axios.get(`${API}/history?limit=${limit}`, {
      headers: getAuthHeaders()
    });
    return response.data;
  },

  deleteAnalysis: async (analysisId) => {
    const response = await axios.delete(`${API}/history/${analysisId}`, {
      headers: getAuthHeaders()
    });
    return response.data;
  },

  // Health Data
  getHealthData: async (days = 30) => {
    const response = await axios.get(`${API}/health-data?days=${days}`, {
      headers: getAuthHeaders()
    });
    return response.data;
  },

  // Stats
  getStats: async () => {
    const response = await axios.get(`${API}/stats`, {
      headers: getAuthHeaders()
    });
    return response.data;
  },

  // Community
  getPosts: async (limit = 20, skip = 0, tag = null) => {
    let url = `${API}/community/posts?limit=${limit}&skip=${skip}`;
    if (tag) url += `&tag=${tag}`;
    const response = await axios.get(url);
    return response.data;
  },

  getPost: async (postId) => {
    const response = await axios.get(`${API}/community/posts/${postId}`);
    return response.data;
  },

  createPost: async (title, content, tags = []) => {
    const response = await axios.post(
      `${API}/community/posts`,
      { title, content, tags },
      { headers: getAuthHeaders() }
    );
    return response.data;
  },

  likePost: async (postId) => {
    const response = await axios.post(
      `${API}/community/posts/${postId}/like`,
      {},
      { headers: getAuthHeaders() }
    );
    return response.data;
  },

  getComments: async (postId) => {
    const response = await axios.get(`${API}/community/posts/${postId}/comments`);
    return response.data;
  },

  createComment: async (postId, content) => {
    const response = await axios.post(
      `${API}/community/posts/${postId}/comments`,
      { content },
      { headers: getAuthHeaders() }
    );
    return response.data;
  },

  // Subscription
  createCheckout: async (originUrl) => {
    const response = await axios.post(
      `${API}/subscription/checkout`,
      { origin_url: originUrl },
      { headers: getAuthHeaders() }
    );
    return response.data;
  },

  getCheckoutStatus: async (sessionId) => {
    const response = await axios.get(`${API}/subscription/status/${sessionId}`, {
      headers: getAuthHeaders()
    });
    return response.data;
  }
};

export default api;
