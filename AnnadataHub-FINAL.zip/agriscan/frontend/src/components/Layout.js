import { NavLink, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { 
  Home, 
  Camera, 
  History, 
  Users, 
  User,
  Activity,
  Leaf,
  CreditCard,
  LogOut,
  Globe,
  Package,
  AlertTriangle
} from 'lucide-react';

const Layout = ({ children }) => {
  const { user, logout } = useAuth();
  const location = useLocation();

  const navItems = [
    { path: '/dashboard', icon: Home, label: 'Home' },
    { path: '/scan', icon: Camera, label: 'Scan' },
    { path: '/alerts', icon: AlertTriangle, label: 'Alerts' },
    { path: '/community', icon: Users, label: 'Community' },
    { path: '/profile', icon: User, label: 'Profile' }
  ];

  const desktopNavItems = [
    { path: '/dashboard', icon: Home, label: 'Dashboard' },
    { path: '/scan', icon: Camera, label: 'Scan Crop' },
    { path: '/advice', icon: Globe, label: 'Crop Advice' },
    { path: '/postharvest', icon: Package, label: 'Post-Harvest' },
    { path: '/alerts', icon: AlertTriangle, label: 'Early Warning' },
    { path: '/history', icon: History, label: 'History' },
    { path: '/health', icon: Activity, label: 'Health Monitoring' },
    { path: '/community', icon: Users, label: 'Community' },
    { path: '/pricing', icon: CreditCard, label: 'Pricing' },
    { path: '/profile', icon: User, label: 'Profile' }
  ];

  const isActive = (path) => location.pathname === path;

  return (
    <div className="min-h-screen bg-[#f8fafc]">
      {/* Desktop Sidebar */}
      <nav className="desktop-nav" data-testid="desktop-nav">
        {/* Logo */}
        <div className="flex items-center gap-2 mb-8">
          <div className="w-10 h-10 bg-white/10 rounded-xl flex items-center justify-center">
            <Leaf className="w-5 h-5 text-white" />
          </div>
          <span className="text-xl font-bold" style={{ fontFamily: 'Outfit, sans-serif' }}>
            AgriScan AI
          </span>
        </div>

        {/* Nav Items */}
        <div className="flex-1 space-y-1">
          {desktopNavItems.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              className={`desktop-nav-item ${isActive(item.path) ? 'active' : ''}`}
              data-testid={`nav-${item.label.toLowerCase().replace(' ', '-')}`}
            >
              <item.icon className="w-5 h-5" />
              <span>{item.label}</span>
            </NavLink>
          ))}
        </div>

        {/* User Info */}
        <div className="mt-auto pt-4 border-t border-white/10">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center text-white font-semibold">
              {user?.name?.charAt(0).toUpperCase() || 'U'}
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-medium truncate">{user?.name}</p>
              <p className="text-xs text-white/60 capitalize">{user?.subscription_tier || 'Free'}</p>
            </div>
          </div>
          <button
            onClick={logout}
            className="flex items-center gap-2 text-white/60 hover:text-white transition-colors text-sm"
            data-testid="desktop-logout-btn"
          >
            <LogOut className="w-4 h-4" />
            Sign Out
          </button>
        </div>
      </nav>

      {/* Mobile Bottom Nav */}
      <nav className="mobile-nav" data-testid="mobile-nav">
        {navItems.map((item, index) => {
          // Make Scan button special (center FAB)
          if (item.path === '/scan') {
            return (
              <NavLink
                key={item.path}
                to={item.path}
                className="relative -mt-6"
                data-testid="mobile-scan-btn"
              >
                <div className="btn-action">
                  <item.icon className="w-6 h-6" />
                </div>
              </NavLink>
            );
          }
          return (
            <NavLink
              key={item.path}
              to={item.path}
              className={`nav-item ${isActive(item.path) ? 'active' : ''}`}
              data-testid={`mobile-nav-${item.label.toLowerCase()}`}
            >
              <item.icon className="w-5 h-5" />
              <span>{item.label}</span>
            </NavLink>
          );
        })}
      </nav>

      {/* Main Content */}
      <main className="main-content">
        {children}
      </main>
    </div>
  );
};

export default Layout;
