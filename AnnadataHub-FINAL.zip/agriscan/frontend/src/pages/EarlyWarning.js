import { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Input } from '../components/ui/input';
import { Textarea } from '../components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../components/ui/dialog';
import { Badge } from '../components/ui/badge';
import { 
  AlertTriangle, 
  MapPin, 
  Plus,
  Bell,
  Bug,
  Shield,
  TrendingUp,
  Loader2,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { toast } from 'sonner';
import Layout from '../components/Layout';

const SEVERITY_COLORS = {
  low: 'bg-blue-100 text-blue-700',
  medium: 'bg-yellow-100 text-yellow-700',
  high: 'bg-orange-100 text-orange-700',
  critical: 'bg-red-100 text-red-700'
};

const CROP_TYPES = [
  'Wheat', 'Rice', 'Corn', 'Tomato', 'Potato', 'Cotton', 'Sugarcane',
  'Soybean', 'Groundnut', 'Mustard', 'Onion', 'Garlic', 'Chilli',
  'Banana', 'Mango', 'Grapes', 'Apple', 'Orange', 'Cabbage', 'Cauliflower'
];

const COMMON_PESTS = [
  'Aphids', 'Whiteflies', 'Armyworm', 'Bollworm', 'Stem Borer', 
  'Fruit Fly', 'Leaf Miner', 'Thrips', 'Mites', 'Locusts',
  'Root Rot', 'Leaf Blight', 'Powdery Mildew', 'Rust', 'Wilt'
];

const EarlyWarning = () => {
  const { isAuthenticated } = useAuth();
  const [loading, setLoading] = useState(true);
  const [warnings, setWarnings] = useState([]);
  const [alerts, setAlerts] = useState([]);
  const [stats, setStats] = useState(null);
  const [location, setLocation] = useState('');
  const [dialogOpen, setDialogOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [reportForm, setReportForm] = useState({
    pest_name: '',
    crop_affected: '',
    severity: 'medium',
    location: '',
    description: ''
  });

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      // Fetch active warnings (public)
      const warningsRes = await fetch(`${process.env.REACT_APP_BACKEND_URL}/api/alerts/warnings`);
      const warningsData = await warningsRes.json();
      setWarnings(warningsData.warnings || []);

      // Fetch stats if authenticated
      if (isAuthenticated) {
        const statsRes = await fetch(`${process.env.REACT_APP_BACKEND_URL}/api/alerts/stats`, {
          headers: { 'Authorization': `Bearer ${localStorage.getItem('agriscan_token')}` }
        });
        const statsData = await statsRes.json();
        setStats(statsData);
      }
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  const searchAlerts = async () => {
    if (!location.trim()) {
      toast.error('Please enter a location');
      return;
    }

    try {
      const res = await fetch(
        `${process.env.REACT_APP_BACKEND_URL}/api/alerts/nearby?location=${encodeURIComponent(location)}`,
        { headers: { 'Authorization': `Bearer ${localStorage.getItem('agriscan_token')}` }}
      );
      const data = await res.json();
      setAlerts(data.alerts || []);
      toast.success(`Found ${data.alerts?.length || 0} alerts near ${location}`);
    } catch (error) {
      toast.error('Failed to search alerts');
    }
  };

  const handleReport = async () => {
    if (!reportForm.pest_name || !reportForm.crop_affected || !reportForm.location) {
      toast.error('Please fill in all required fields');
      return;
    }

    setSubmitting(true);
    try {
      const res = await fetch(`${process.env.REACT_APP_BACKEND_URL}/api/alerts/report`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('agriscan_token')}`
        },
        body: JSON.stringify(reportForm)
      });

      if (!res.ok) throw new Error('Failed to submit report');

      toast.success('Alert reported successfully! Thank you for contributing.');
      setDialogOpen(false);
      setReportForm({
        pest_name: '',
        crop_affected: '',
        severity: 'medium',
        location: '',
        description: ''
      });
      fetchData();
    } catch (error) {
      toast.error('Failed to submit report');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Layout>
      <div className="p-6 max-w-5xl mx-auto" data-testid="early-warning-page">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold text-[#0f172a]" style={{ fontFamily: 'Outfit, sans-serif' }}>
              Pest & Disease Early Warning
            </h1>
            <p className="text-gray-600 mt-1">Community-powered alert network for farmers</p>
          </div>
          {isAuthenticated && (
            <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
              <DialogTrigger asChild>
                <Button className="bg-red-500 hover:bg-red-600" data-testid="report-alert-btn">
                  <AlertTriangle className="w-4 h-4 mr-2" />
                  Report Alert
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-lg">
                <DialogHeader>
                  <DialogTitle style={{ fontFamily: 'Outfit, sans-serif' }}>Report Pest/Disease Alert</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 mt-4">
                  <div>
                    <label className="text-sm font-medium mb-1 block">Pest/Disease Name *</label>
                    <Select value={reportForm.pest_name} onValueChange={(v) => setReportForm({...reportForm, pest_name: v})}>
                      <SelectTrigger data-testid="pest-select">
                        <SelectValue placeholder="Select or type pest/disease" />
                      </SelectTrigger>
                      <SelectContent>
                        {COMMON_PESTS.map(pest => (
                          <SelectItem key={pest} value={pest}>{pest}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-1 block">Affected Crop *</label>
                    <Select value={reportForm.crop_affected} onValueChange={(v) => setReportForm({...reportForm, crop_affected: v})}>
                      <SelectTrigger data-testid="crop-select">
                        <SelectValue placeholder="Select crop" />
                      </SelectTrigger>
                      <SelectContent>
                        {CROP_TYPES.map(crop => (
                          <SelectItem key={crop} value={crop}>{crop}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-1 block">Severity *</label>
                    <Select value={reportForm.severity} onValueChange={(v) => setReportForm({...reportForm, severity: v})}>
                      <SelectTrigger data-testid="severity-select">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="low">Low</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="high">High</SelectItem>
                        <SelectItem value="critical">Critical</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-1 block">Location *</label>
                    <Input 
                      placeholder="e.g., Amritsar, Punjab"
                      value={reportForm.location}
                      onChange={(e) => setReportForm({...reportForm, location: e.target.value})}
                      data-testid="location-input"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-1 block">Description</label>
                    <Textarea 
                      placeholder="Describe what you observed..."
                      value={reportForm.description}
                      onChange={(e) => setReportForm({...reportForm, description: e.target.value})}
                      rows={3}
                      data-testid="description-input"
                    />
                  </div>
                  <Button 
                    className="w-full bg-red-500 hover:bg-red-600"
                    onClick={handleReport}
                    disabled={submitting}
                    data-testid="submit-report-btn"
                  >
                    {submitting ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Submitting...
                      </>
                    ) : (
                      'Submit Report'
                    )}
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          )}
        </div>

        {/* Stats Cards */}
        {stats && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
            <Card className="border-0 shadow-md">
              <CardContent className="p-4 text-center">
                <Bug className="w-8 h-8 text-orange-500 mx-auto mb-2" />
                <p className="text-2xl font-bold">{stats.total_alerts}</p>
                <p className="text-sm text-gray-500">Total Reports</p>
              </CardContent>
            </Card>
            <Card className="border-0 shadow-md">
              <CardContent className="p-4 text-center">
                <Bell className="w-8 h-8 text-red-500 mx-auto mb-2" />
                <p className="text-2xl font-bold">{stats.active_warnings}</p>
                <p className="text-sm text-gray-500">Active Warnings</p>
              </CardContent>
            </Card>
            <Card className="border-0 shadow-md">
              <CardContent className="p-4 text-center">
                <AlertCircle className="w-8 h-8 text-yellow-500 mx-auto mb-2" />
                <p className="text-2xl font-bold">{stats.severity_breakdown?.high || 0}</p>
                <p className="text-sm text-gray-500">High Severity</p>
              </CardContent>
            </Card>
            <Card className="border-0 shadow-md">
              <CardContent className="p-4 text-center">
                <Shield className="w-8 h-8 text-green-500 mx-auto mb-2" />
                <p className="text-2xl font-bold">{stats.top_reported_pests?.length || 0}</p>
                <p className="text-sm text-gray-500">Tracked Pests</p>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Search Alerts */}
        <Card className="border-0 shadow-lg mb-6" data-testid="search-alerts-card">
          <CardContent className="p-4">
            <div className="flex gap-3">
              <div className="flex-1 relative">
                <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <Input 
                  placeholder="Enter your location to find nearby alerts..."
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  className="pl-9"
                  data-testid="search-location-input"
                />
              </div>
              <Button 
                className="bg-[#1a4d2e] hover:bg-[#2d6a4f]"
                onClick={searchAlerts}
                data-testid="search-btn"
              >
                Search Alerts
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Active Warnings */}
        <h2 className="text-xl font-semibold mb-4" style={{ fontFamily: 'Outfit, sans-serif' }}>
          <Bell className="w-5 h-5 inline mr-2 text-red-500" />
          Active Warnings
        </h2>
        {loading ? (
          <div className="flex justify-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-gray-400" />
          </div>
        ) : warnings.length === 0 ? (
          <Card className="border-0 shadow-lg mb-6">
            <CardContent className="p-8 text-center">
              <CheckCircle2 className="w-16 h-16 text-green-500 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-700">No Active Warnings</h3>
              <p className="text-gray-500">Your region is currently safe. Stay vigilant!</p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-4 mb-8">
            {warnings.map((warning) => (
              <Card key={warning.id} className="border-0 shadow-lg border-l-4 border-l-red-500" data-testid={`warning-${warning.id}`}>
                <CardContent className="p-5">
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="flex items-center gap-2 mb-2">
                        <AlertTriangle className="w-5 h-5 text-red-500" />
                        <h3 className="font-semibold text-lg">{warning.title}</h3>
                        <Badge className={SEVERITY_COLORS[warning.severity]}>
                          {warning.severity}
                        </Badge>
                      </div>
                      <p className="text-gray-600 mb-3">{warning.description}</p>
                      <div className="flex flex-wrap gap-2 mb-3">
                        {warning.affected_crops?.map((crop) => (
                          <Badge key={crop} variant="outline">{crop}</Badge>
                        ))}
                      </div>
                      {warning.prevention_tips?.length > 0 && (
                        <div className="bg-green-50 p-3 rounded-lg">
                          <p className="text-sm font-medium text-green-700 mb-1">Prevention Tips:</p>
                          <ul className="text-sm text-green-600 list-disc list-inside">
                            {warning.prevention_tips.map((tip, i) => (
                              <li key={i}>{tip}</li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Nearby Alerts */}
        {alerts.length > 0 && (
          <>
            <h2 className="text-xl font-semibold mb-4" style={{ fontFamily: 'Outfit, sans-serif' }}>
              <MapPin className="w-5 h-5 inline mr-2 text-blue-500" />
              Alerts Near {location}
            </h2>
            <div className="space-y-3">
              {alerts.map((alert) => (
                <Card key={alert.id} className="border-0 shadow-md" data-testid={`alert-${alert.id}`}>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <Bug className="w-8 h-8 text-orange-500" />
                        <div>
                          <p className="font-semibold">{alert.pest_name}</p>
                          <p className="text-sm text-gray-500">
                            {alert.crop_affected} • {alert.location}
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <Badge className={SEVERITY_COLORS[alert.severity]}>
                          {alert.severity}
                        </Badge>
                        {alert.verified && (
                          <p className="text-xs text-green-600 mt-1">Verified</p>
                        )}
                      </div>
                    </div>
                    {alert.description && (
                      <p className="text-sm text-gray-600 mt-2">{alert.description}</p>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          </>
        )}
      </div>
    </Layout>
  );
};

export default EarlyWarning;
