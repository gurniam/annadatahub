import { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import api from '../services/api';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '../components/ui/accordion';
import { 
  ArrowLeft, 
  AlertTriangle, 
  CheckCircle2, 
  Pill, 
  Shield, 
  Info,
  Camera,
  Share2,
  Printer,
  Leaf
} from 'lucide-react';
import { toast } from 'sonner';
import Layout from '../components/Layout';

const Result = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchResult = async () => {
      try {
        const data = await api.getAnalysis(id);
        setResult(data);
      } catch (error) {
        console.error('Error fetching result:', error);
        toast.error('Could not load analysis result');
        navigate('/dashboard');
      } finally {
        setLoading(false);
      }
    };
    fetchResult();
  }, [id, navigate]);

  const getSeverityConfig = (severity) => {
    const configs = {
      healthy: {
        color: 'text-green-600',
        bg: 'bg-green-100',
        icon: <CheckCircle2 className="w-6 h-6" />,
        label: 'Healthy'
      },
      mild: {
        color: 'text-blue-600',
        bg: 'bg-blue-100',
        icon: <Info className="w-6 h-6" />,
        label: 'Mild'
      },
      moderate: {
        color: 'text-orange-500',
        bg: 'bg-orange-100',
        icon: <AlertTriangle className="w-6 h-6" />,
        label: 'Moderate'
      },
      severe: {
        color: 'text-red-600',
        bg: 'bg-red-100',
        icon: <AlertTriangle className="w-6 h-6" />,
        label: 'Severe'
      },
      critical: {
        color: 'text-red-700',
        bg: 'bg-red-200',
        icon: <AlertTriangle className="w-6 h-6" />,
        label: 'Critical'
      }
    };
    return configs[severity] || configs.mild;
  };

  const handleShare = async () => {
    try {
      await navigator.share({
        title: `AgriScan AI - ${result.disease_name}`,
        text: `Diagnosis: ${result.disease_name}\nSeverity: ${result.severity}\nTreatment: ${result.treatment}`,
        url: window.location.href
      });
    } catch (error) {
      // Fallback to copying link
      navigator.clipboard.writeText(window.location.href);
      toast.success('Link copied to clipboard!');
    }
  };

  if (loading) {
    return (
      <Layout>
        <div className="flex items-center justify-center min-h-[60vh]">
          <div className="loading-spinner"></div>
        </div>
      </Layout>
    );
  }

  if (!result) {
    return (
      <Layout>
        <div className="p-6 text-center">
          <p>Result not found</p>
          <Link to="/dashboard">
            <Button className="mt-4">Back to Dashboard</Button>
          </Link>
        </div>
      </Layout>
    );
  }

  const severityConfig = getSeverityConfig(result.severity);
  const confidencePercent = Math.round(result.confidence * 100);

  return (
    <Layout>
      <div className="p-6 max-w-3xl mx-auto" data-testid="result-page">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <Button
            variant="ghost"
            onClick={() => navigate(-1)}
            className="text-gray-600"
            data-testid="back-btn"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="icon"
              onClick={handleShare}
              data-testid="share-btn"
            >
              <Share2 className="w-4 h-4" />
            </Button>
            <Button
              variant="outline"
              size="icon"
              onClick={() => window.print()}
              data-testid="print-btn"
            >
              <Printer className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* Main Result Card */}
        <Card className="border-0 shadow-xl mb-6 overflow-hidden" data-testid="result-card">
          <div className={`${severityConfig.bg} p-6`}>
            <div className="flex items-center gap-4">
              <div className={`w-14 h-14 rounded-full bg-white flex items-center justify-center ${severityConfig.color}`}>
                {severityConfig.icon}
              </div>
              <div>
                <h1 className="text-2xl font-bold text-[#0f172a]" style={{ fontFamily: 'Outfit, sans-serif' }}>
                  {result.disease_name}
                </h1>
                <div className="flex items-center gap-3 mt-1">
                  <span className={`px-3 py-1 rounded-full text-sm font-semibold ${severityConfig.bg} ${severityConfig.color} border border-current`}>
                    {severityConfig.label}
                  </span>
                  <span className="text-sm text-gray-600">
                    {confidencePercent}% confidence
                  </span>
                </div>
              </div>
            </div>
          </div>
          <CardContent className="p-6">
            {/* Crop Info */}
            <div className="flex items-center gap-2 text-gray-600 mb-4">
              <Leaf className="w-4 h-4" />
              <span>Crop: <strong>{result.crop_type}</strong></span>
              <span className="mx-2">•</span>
              <span>Analyzed: {new Date(result.created_at).toLocaleDateString()}</span>
            </div>

            {/* Description */}
            <div className="prose prose-sm max-w-none">
              <p className="text-gray-700">{result.description}</p>
            </div>
          </CardContent>
        </Card>

        {/* Treatment & Prevention */}
        <div className="grid md:grid-cols-2 gap-4 mb-6">
          <Card className="border-0 shadow-lg" data-testid="treatment-card">
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2 text-lg" style={{ fontFamily: 'Outfit, sans-serif' }}>
                <Pill className="w-5 h-5 text-[#1a4d2e]" />
                Treatment
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-700 text-sm leading-relaxed">{result.treatment}</p>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg" data-testid="prevention-card">
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2 text-lg" style={{ fontFamily: 'Outfit, sans-serif' }}>
                <Shield className="w-5 h-5 text-[#1a4d2e]" />
                Prevention
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-700 text-sm leading-relaxed">{result.prevention}</p>
            </CardContent>
          </Card>
        </div>

        {/* Detailed Analysis Accordion */}
        <Card className="border-0 shadow-lg mb-6" data-testid="details-accordion">
          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="details" className="border-none">
              <AccordionTrigger className="px-6 py-4 hover:no-underline">
                <span className="flex items-center gap-2" style={{ fontFamily: 'Outfit, sans-serif' }}>
                  <Info className="w-5 h-5 text-[#1a4d2e]" />
                  View Detailed Analysis
                </span>
              </AccordionTrigger>
              <AccordionContent className="px-6 pb-6">
                <div className="space-y-4 text-sm">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="p-4 bg-gray-50 rounded-lg">
                      <p className="text-gray-500 text-xs mb-1">Analysis ID</p>
                      <p className="font-mono text-xs">{result.id}</p>
                    </div>
                    <div className="p-4 bg-gray-50 rounded-lg">
                      <p className="text-gray-500 text-xs mb-1">Confidence Score</p>
                      <p className="font-semibold">{confidencePercent}%</p>
                    </div>
                    <div className="p-4 bg-gray-50 rounded-lg">
                      <p className="text-gray-500 text-xs mb-1">Severity Level</p>
                      <p className="font-semibold capitalize">{result.severity}</p>
                    </div>
                    <div className="p-4 bg-gray-50 rounded-lg">
                      <p className="text-gray-500 text-xs mb-1">Timestamp</p>
                      <p className="font-mono text-xs">{new Date(result.created_at).toISOString()}</p>
                    </div>
                  </div>
                </div>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </Card>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-3">
          <Link to="/scan" className="flex-1">
            <Button 
              className="w-full bg-[#1a4d2e] hover:bg-[#2d6a4f]"
              data-testid="scan-another-btn"
            >
              <Camera className="w-4 h-4 mr-2" />
              Scan Another Crop
            </Button>
          </Link>
          <Link to="/community" className="flex-1">
            <Button 
              variant="outline"
              className="w-full border-[#1a4d2e] text-[#1a4d2e] hover:bg-[#1a4d2e] hover:text-white"
              data-testid="ask-community-btn"
            >
              Ask the Community
            </Button>
          </Link>
        </div>
      </div>
    </Layout>
  );
};

export default Result;
