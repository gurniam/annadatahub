import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import api from '../services/api';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Input } from '../components/ui/input';
import { Textarea } from '../components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../components/ui/dialog';
import { Badge } from '../components/ui/badge';
import { 
  Users, 
  Plus, 
  Heart, 
  MessageCircle, 
  Search,
  Send,
  ChevronRight
} from 'lucide-react';
import { toast } from 'sonner';
import Layout from '../components/Layout';

const Community = () => {
  const { isAuthenticated } = useAuth();
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedTag, setSelectedTag] = useState(null);
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [newPost, setNewPost] = useState({ title: '', content: '', tags: '' });
  const [submitting, setSubmitting] = useState(false);

  const popularTags = ['wheat', 'tomato', 'disease', 'treatment', 'tips', 'organic'];

  useEffect(() => {
    fetchPosts();
  }, [selectedTag]);

  const fetchPosts = async () => {
    try {
      const data = await api.getPosts(20, 0, selectedTag);
      setPosts(data);
    } catch (error) {
      console.error('Error fetching posts:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleCreatePost = async () => {
    if (!newPost.title.trim() || !newPost.content.trim()) {
      toast.error('Please fill in all fields');
      return;
    }

    setSubmitting(true);
    try {
      const tags = newPost.tags.split(',').map(t => t.trim().toLowerCase()).filter(Boolean);
      const post = await api.createPost(newPost.title, newPost.content, tags);
      setPosts([post, ...posts]);
      setNewPost({ title: '', content: '', tags: '' });
      setCreateDialogOpen(false);
      toast.success('Post created successfully!');
    } catch (error) {
      toast.error('Failed to create post');
    } finally {
      setSubmitting(false);
    }
  };

  const handleLike = async (postId) => {
    if (!isAuthenticated) {
      toast.error('Please login to like posts');
      return;
    }

    try {
      const result = await api.likePost(postId);
      setPosts(posts.map(post => {
        if (post.id === postId) {
          return {
            ...post,
            likes: result.liked ? post.likes + 1 : post.likes - 1
          };
        }
        return post;
      }));
    } catch (error) {
      toast.error('Failed to like post');
    }
  };

  const filteredPosts = posts.filter(post =>
    post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    post.content.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getInitials = (name) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
  };

  return (
    <Layout>
      <div className="p-6 max-w-4xl mx-auto" data-testid="community-page">
        {/* Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold text-[#0f172a]" style={{ fontFamily: 'Outfit, sans-serif' }}>
              Community Forum
            </h1>
            <p className="text-gray-600 mt-1">Connect with fellow farmers and share knowledge</p>
          </div>
          {isAuthenticated ? (
            <Dialog open={createDialogOpen} onOpenChange={setCreateDialogOpen}>
              <DialogTrigger asChild>
                <Button className="bg-[#1a4d2e] hover:bg-[#2d6a4f]" data-testid="create-post-btn">
                  <Plus className="w-4 h-4 mr-2" />
                  New Post
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-lg">
                <DialogHeader>
                  <DialogTitle style={{ fontFamily: 'Outfit, sans-serif' }}>Create a Post</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 mt-4">
                  <div>
                    <Input
                      placeholder="Post title..."
                      value={newPost.title}
                      onChange={(e) => setNewPost({ ...newPost, title: e.target.value })}
                      data-testid="post-title-input"
                    />
                  </div>
                  <div>
                    <Textarea
                      placeholder="Share your question, experience, or tips..."
                      rows={5}
                      value={newPost.content}
                      onChange={(e) => setNewPost({ ...newPost, content: e.target.value })}
                      data-testid="post-content-input"
                    />
                  </div>
                  <div>
                    <Input
                      placeholder="Tags (comma separated): wheat, disease, tips"
                      value={newPost.tags}
                      onChange={(e) => setNewPost({ ...newPost, tags: e.target.value })}
                      data-testid="post-tags-input"
                    />
                  </div>
                  <Button 
                    className="w-full bg-[#1a4d2e] hover:bg-[#2d6a4f]"
                    onClick={handleCreatePost}
                    disabled={submitting}
                    data-testid="submit-post-btn"
                  >
                    {submitting ? 'Posting...' : 'Post'}
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          ) : (
            <Link to="/login">
              <Button variant="outline" data-testid="login-to-post-btn">
                Login to Post
              </Button>
            </Link>
          )}
        </div>

        {/* Search & Tags */}
        <Card className="border-0 shadow-md mb-6" data-testid="search-tags-card">
          <CardContent className="p-4">
            <div className="relative mb-4">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input
                placeholder="Search posts..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-9"
                data-testid="search-posts-input"
              />
            </div>
            <div className="flex flex-wrap gap-2">
              <Badge 
                variant={selectedTag === null ? 'default' : 'outline'}
                className={`cursor-pointer ${selectedTag === null ? 'bg-[#1a4d2e]' : ''}`}
                onClick={() => setSelectedTag(null)}
              >
                All
              </Badge>
              {popularTags.map(tag => (
                <Badge 
                  key={tag}
                  variant={selectedTag === tag ? 'default' : 'outline'}
                  className={`cursor-pointer ${selectedTag === tag ? 'bg-[#1a4d2e]' : ''}`}
                  onClick={() => setSelectedTag(tag)}
                  data-testid={`tag-${tag}`}
                >
                  #{tag}
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Posts List */}
        {loading ? (
          <div className="flex items-center justify-center py-12">
            <div className="loading-spinner"></div>
          </div>
        ) : filteredPosts.length === 0 ? (
          <Card className="border-0 shadow-lg" data-testid="empty-posts">
            <CardContent className="p-12 text-center">
              <Users className="w-16 h-16 mx-auto text-gray-300 mb-4" />
              <h2 className="text-xl font-semibold text-gray-700 mb-2" style={{ fontFamily: 'Outfit, sans-serif' }}>
                No posts yet
              </h2>
              <p className="text-gray-500">Be the first to start a discussion!</p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-4">
            {filteredPosts.map(post => (
              <Link key={post.id} to={`/community/${post.id}`} data-testid={`post-${post.id}`}>
                <Card className="border-0 shadow-md hover:shadow-lg transition-all cursor-pointer mb-4">
                  <CardContent className="p-5">
                    {/* Author */}
                    <div className="flex items-center gap-3 mb-3">
                      <div className="w-10 h-10 rounded-full bg-[#1a4d2e] text-white flex items-center justify-center font-semibold text-sm">
                        {getInitials(post.user_name)}
                      </div>
                      <div>
                        <p className="font-medium text-[#0f172a]">{post.user_name}</p>
                        <p className="text-xs text-gray-500">
                          {new Date(post.created_at).toLocaleDateString()}
                        </p>
                      </div>
                    </div>

                    {/* Content */}
                    <h3 className="text-lg font-semibold text-[#0f172a] mb-2" style={{ fontFamily: 'Outfit, sans-serif' }}>
                      {post.title}
                    </h3>
                    <p className="text-gray-600 text-sm line-clamp-2 mb-3">
                      {post.content}
                    </p>

                    {/* Tags */}
                    {post.tags?.length > 0 && (
                      <div className="flex flex-wrap gap-1 mb-3">
                        {post.tags.map(tag => (
                          <Badge key={tag} variant="secondary" className="text-xs">
                            #{tag}
                          </Badge>
                        ))}
                      </div>
                    )}

                    {/* Actions */}
                    <div className="flex items-center justify-between pt-3 border-t border-gray-100">
                      <div className="flex gap-4">
                        <button
                          className="flex items-center gap-1 text-gray-500 hover:text-red-500 transition-colors"
                          onClick={(e) => {
                            e.preventDefault();
                            handleLike(post.id);
                          }}
                          data-testid={`like-btn-${post.id}`}
                        >
                          <Heart className="w-4 h-4" />
                          <span className="text-sm">{post.likes}</span>
                        </button>
                        <span className="flex items-center gap-1 text-gray-500">
                          <MessageCircle className="w-4 h-4" />
                          <span className="text-sm">{post.comments_count}</span>
                        </span>
                      </div>
                      <ChevronRight className="w-5 h-5 text-gray-300" />
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        )}
      </div>
    </Layout>
  );
};

export default Community;
