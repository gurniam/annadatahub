import { useState, useEffect } from 'react';
import api from '../services/api';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Input } from '../components/ui/input';
import { Textarea } from '../components/ui/textarea';
import { 
  Globe, 
  Lightbulb, 
  Cloud, 
  TrendingUp,
  Loader2,
  Leaf,
  MapPin,
  ThermometerSun
} from 'lucide-react';
import { toast } from 'sonner';
import Layout from '../components/Layout';

const LANGUAGES = {
  "en": "English",
  "hi": "Hindi (हिंदी)",
  "bn": "Bengali (বাংলা)",
  "te": "Telugu (తెలుగు)",
  "mr": "Marathi (मराठी)",
  "ta": "Tamil (தமிழ்)",
  "gu": "Gujarati (ગુજરાતી)",
  "kn": "Kannada (ಕನ್ನಡ)",
  "ml": "Malayalam (മലയാളം)",
  "pa": "Punjabi (ਪੰਜਾਬੀ)",
  "or": "Odia (ଓଡ଼ିଆ)",
  "as": "Assamese (অসমীয়া)",
  "ur": "Urdu (اردو)"
};

const CROP_TYPES = [
  'Wheat', 'Rice', 'Corn', 'Tomato', 'Potato', 'Cotton', 'Sugarcane',
  'Soybean', 'Groundnut', 'Mustard', 'Onion', 'Garlic', 'Chilli',
  'Turmeric', 'Ginger', 'Banana', 'Mango', 'Grapes', 'Apple', 'Orange'
];

const GROWTH_STAGES = [
  'Germination', 'Seedling', 'Vegetative', 'Flowering', 'Fruiting', 'Maturity', 'Harvest'
];

const SOIL_TYPES = [
  'Clay', 'Sandy', 'Loamy', 'Silt', 'Peaty', 'Chalky', 'Black Cotton'
];

const PersonalizedAdvice = () => {
  const [loading, setLoading] = useState(false);
  const [advice, setAdvice] = useState(null);
  const [formData, setFormData] = useState({
    crop_type: '',
    region: '',
    language: 'en',
    growth_stage: '',
    soil_type: '',
    weather_conditions: ''
  });

  const handleSubmit = async () => {
    if (!formData.crop_type) {
      toast.error('Please select a crop type');
      return;
    }

    setLoading(true);
    try {
      const response = await fetch(`${process.env.REACT_APP_BACKEND_URL}/api/advice/personalized`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('agriscan_token')}`
        },
        body: JSON.stringify(formData)
      });
      
      if (!response.ok) throw new Error('Failed to get advice');
      
      const data = await response.json();
      setAdvice(data);
      toast.success('Personalized advice generated!');
    } catch (error) {
      console.error('Error:', error);
      toast.error('Failed to get advice. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Layout>
      <div className="p-6 max-w-4xl mx-auto" data-testid="personalized-advice-page">
        <div className="mb-8">
          <h1 className="text-2xl md:text-3xl font-bold text-[#0f172a]" style={{ fontFamily: 'Outfit, sans-serif' }}>
            Personalized Crop Advice
          </h1>
          <p className="text-gray-600 mt-1">Get AI-powered advice in your preferred language</p>
        </div>

        {/* Language Selection Banner */}
        <Card className="border-0 shadow-md bg-gradient-to-r from-[#1a4d2e] to-[#2d6a4f] text-white mb-6" data-testid="language-banner">
          <CardContent className="p-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Globe className="w-6 h-6" />
              <span className="font-medium">Available in 12+ Regional Languages</span>
            </div>
            <Select value={formData.language} onValueChange={(v) => setFormData({...formData, language: v})}>
              <SelectTrigger className="w-48 bg-white/20 border-white/30 text-white" data-testid="language-select">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {Object.entries(LANGUAGES).map(([code, name]) => (
                  <SelectItem key={code} value={code}>{name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </CardContent>
        </Card>

        {/* Input Form */}
        <Card className="border-0 shadow-lg mb-6" data-testid="advice-form">
          <CardHeader>
            <CardTitle style={{ fontFamily: 'Outfit, sans-serif' }}>Tell us about your crop</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-gray-700 mb-1 block">Crop Type *</label>
                <Select value={formData.crop_type} onValueChange={(v) => setFormData({...formData, crop_type: v})}>
                  <SelectTrigger data-testid="crop-select">
                    <SelectValue placeholder="Select crop" />
                  </SelectTrigger>
                  <SelectContent>
                    {CROP_TYPES.map(crop => (
                      <SelectItem key={crop} value={crop}>{crop}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700 mb-1 block">Region/Location</label>
                <Input 
                  placeholder="e.g., Punjab, Maharashtra"
                  value={formData.region}
                  onChange={(e) => setFormData({...formData, region: e.target.value})}
                  data-testid="region-input"
                />
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700 mb-1 block">Growth Stage</label>
                <Select value={formData.growth_stage} onValueChange={(v) => setFormData({...formData, growth_stage: v})}>
                  <SelectTrigger data-testid="stage-select">
                    <SelectValue placeholder="Select stage" />
                  </SelectTrigger>
                  <SelectContent>
                    {GROWTH_STAGES.map(stage => (
                      <SelectItem key={stage} value={stage}>{stage}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700 mb-1 block">Soil Type</label>
                <Select value={formData.soil_type} onValueChange={(v) => setFormData({...formData, soil_type: v})}>
                  <SelectTrigger data-testid="soil-select">
                    <SelectValue placeholder="Select soil type" />
                  </SelectTrigger>
                  <SelectContent>
                    {SOIL_TYPES.map(soil => (
                      <SelectItem key={soil} value={soil}>{soil}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div>
              <label className="text-sm font-medium text-gray-700 mb-1 block">Current Weather Conditions</label>
              <Textarea 
                placeholder="Describe current weather (e.g., Hot and dry, recent rainfall, monsoon season)"
                value={formData.weather_conditions}
                onChange={(e) => setFormData({...formData, weather_conditions: e.target.value})}
                rows={2}
                data-testid="weather-input"
              />
            </div>
            <Button 
              className="w-full bg-[#1a4d2e] hover:bg-[#2d6a4f]"
              onClick={handleSubmit}
              disabled={loading}
              data-testid="get-advice-btn"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Generating Advice...
                </>
              ) : (
                <>
                  <Lightbulb className="w-4 h-4 mr-2" />
                  Get Personalized Advice
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        {/* Advice Results */}
        {advice && (
          <div className="space-y-4 fade-in" data-testid="advice-results">
            <Card className="border-0 shadow-lg">
              <CardHeader className="bg-[#1a4d2e]/5">
                <CardTitle className="flex items-center gap-2" style={{ fontFamily: 'Outfit, sans-serif' }}>
                  <Leaf className="w-5 h-5 text-[#1a4d2e]" />
                  Personalized Advice for {advice.crop_type}
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                <p className="text-gray-700 leading-relaxed">{advice.advice}</p>
              </CardContent>
            </Card>

            {advice.tips?.length > 0 && (
              <Card className="border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2" style={{ fontFamily: 'Outfit, sans-serif' }}>
                    <Lightbulb className="w-5 h-5 text-[#f9d71c]" />
                    Key Tips
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2">
                    {advice.tips.map((tip, index) => (
                      <li key={index} className="flex items-start gap-2">
                        <span className="w-6 h-6 bg-[#1a4d2e]/10 text-[#1a4d2e] rounded-full flex items-center justify-center flex-shrink-0 text-sm font-medium">
                          {index + 1}
                        </span>
                        <span className="text-gray-700">{tip}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            )}

            <div className="grid md:grid-cols-2 gap-4">
              {advice.weather_alert && (
                <Card className="border-0 shadow-lg border-l-4 border-l-orange-500">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2 mb-2">
                      <Cloud className="w-5 h-5 text-orange-500" />
                      <span className="font-semibold text-orange-700">Weather Alert</span>
                    </div>
                    <p className="text-gray-700 text-sm">{advice.weather_alert}</p>
                  </CardContent>
                </Card>
              )}

              {advice.market_info && (
                <Card className="border-0 shadow-lg border-l-4 border-l-blue-500">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2 mb-2">
                      <TrendingUp className="w-5 h-5 text-blue-500" />
                      <span className="font-semibold text-blue-700">Market Insights</span>
                    </div>
                    <p className="text-gray-700 text-sm">{advice.market_info}</p>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>
        )}
      </div>
    </Layout>
  );
};

export default PersonalizedAdvice;
