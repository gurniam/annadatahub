import { useState, useEffect } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import api from '../services/api';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { 
  Check, 
  Zap, 
  Crown, 
  Loader2,
  CheckCircle2
} from 'lucide-react';
import { toast } from 'sonner';
import Layout from '../components/Layout';

const Pricing = () => {
  const { isAuthenticated, user, refreshUser } = useAuth();
  const [searchParams] = useSearchParams();
  const [loading, setLoading] = useState(false);
  const [checkingPayment, setCheckingPayment] = useState(false);

  useEffect(() => {
    const sessionId = searchParams.get('session_id');
    if (sessionId) {
      pollPaymentStatus(sessionId);
    }
  }, [searchParams]);

  const pollPaymentStatus = async (sessionId, attempts = 0) => {
    if (attempts >= 5) {
      toast.error('Payment verification timed out. Please check your account.');
      return;
    }

    setCheckingPayment(true);
    try {
      const status = await api.getCheckoutStatus(sessionId);
      if (status.payment_status === 'paid') {
        toast.success('Payment successful! Welcome to Premium!');
        refreshUser();
        setCheckingPayment(false);
        // Remove session_id from URL
        window.history.replaceState({}, '', '/pricing');
      } else if (status.status === 'expired') {
        toast.error('Payment session expired. Please try again.');
        setCheckingPayment(false);
      } else {
        // Continue polling
        setTimeout(() => pollPaymentStatus(sessionId, attempts + 1), 2000);
      }
    } catch (error) {
      console.error('Error checking payment status:', error);
      setCheckingPayment(false);
    }
  };

  const handleUpgrade = async () => {
    if (!isAuthenticated) {
      toast.error('Please login to upgrade');
      return;
    }

    setLoading(true);
    try {
      const { url } = await api.createCheckout(window.location.origin);
      window.location.href = url;
    } catch (error) {
      console.error('Error creating checkout:', error);
      toast.error('Could not initiate checkout. Please try again.');
      setLoading(false);
    }
  };

  const isPremium = user?.subscription_tier === 'premium';

  const plans = [
    {
      name: 'Free',
      price: 0,
      period: 'forever',
      description: 'Perfect for getting started',
      features: [
        '5 scans per month',
        'Basic disease identification',
        'Treatment recommendations',
        'Community access',
        'Email support'
      ],
      current: !isPremium,
      cta: isPremium ? 'Current Plan: Premium' : 'Current Plan'
    },
    {
      name: 'Premium',
      price: 9.99,
      period: 'month',
      description: 'For serious farmers',
      features: [
        'Unlimited scans',
        'Advanced AI analysis',
        'Detailed treatment plans',
        'Health monitoring & analytics',
        'Priority support',
        'Early access to new features'
      ],
      current: isPremium,
      featured: true,
      cta: isPremium ? 'Current Plan' : 'Upgrade Now'
    }
  ];

  return (
    <Layout>
      <div className="p-6 max-w-5xl mx-auto" data-testid="pricing-page">
        {/* Payment Checking Overlay */}
        {checkingPayment && (
          <div className="fixed inset-0 bg-white/90 flex flex-col items-center justify-center z-50">
            <Loader2 className="w-12 h-12 text-[#1a4d2e] animate-spin mb-4" />
            <p className="text-lg font-medium">Verifying your payment...</p>
          </div>
        )}

        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-3xl md:text-4xl font-bold text-[#0f172a] mb-4" style={{ fontFamily: 'Outfit, sans-serif' }}>
            Simple, Transparent Pricing
          </h1>
          <p className="text-gray-600 max-w-xl mx-auto">
            Start free and upgrade when you need more. No hidden fees, cancel anytime.
          </p>
        </div>

        {/* Pricing Cards */}
        <div className="grid md:grid-cols-2 gap-8 max-w-3xl mx-auto">
          {plans.map((plan, index) => (
            <Card 
              key={plan.name}
              className={`border-2 ${plan.featured ? 'border-[#1a4d2e] shadow-xl scale-105' : 'border-gray-200 shadow-lg'} relative overflow-hidden`}
              data-testid={`plan-${plan.name.toLowerCase()}`}
            >
              {plan.featured && (
                <div className="absolute top-0 right-0 bg-[#f9d71c] text-[#0f172a] text-xs font-bold px-3 py-1 rounded-bl-lg flex items-center gap-1">
                  <Crown className="w-3 h-3" />
                  POPULAR
                </div>
              )}
              <CardHeader className="text-center pb-4">
                <CardTitle className="text-xl mb-2" style={{ fontFamily: 'Outfit, sans-serif' }}>
                  {plan.name}
                </CardTitle>
                <p className="text-sm text-gray-500">{plan.description}</p>
              </CardHeader>
              <CardContent className="text-center">
                <div className="mb-6">
                  <span className="text-4xl font-bold text-[#0f172a]" style={{ fontFamily: 'Outfit, sans-serif' }}>
                    ${plan.price}
                  </span>
                  <span className="text-gray-500">/{plan.period}</span>
                </div>

                {/* Features */}
                <ul className="space-y-3 mb-8 text-left">
                  {plan.features.map((feature, i) => (
                    <li key={i} className="flex items-start gap-2">
                      <Check className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
                      <span className="text-gray-700 text-sm">{feature}</span>
                    </li>
                  ))}
                </ul>

                {/* CTA Button */}
                {plan.current ? (
                  <Button
                    disabled
                    className="w-full bg-gray-100 text-gray-600"
                    data-testid={`${plan.name.toLowerCase()}-btn`}
                  >
                    <CheckCircle2 className="w-4 h-4 mr-2" />
                    {plan.cta}
                  </Button>
                ) : plan.price === 0 ? (
                  <Link to={isAuthenticated ? "/dashboard" : "/register"}>
                    <Button
                      variant="outline"
                      className="w-full border-[#1a4d2e] text-[#1a4d2e]"
                      data-testid={`${plan.name.toLowerCase()}-btn`}
                    >
                      {isAuthenticated ? 'Go to Dashboard' : 'Get Started Free'}
                    </Button>
                  </Link>
                ) : (
                  <Button
                    className="w-full bg-[#1a4d2e] hover:bg-[#2d6a4f]"
                    onClick={handleUpgrade}
                    disabled={loading || !isAuthenticated}
                    data-testid={`${plan.name.toLowerCase()}-btn`}
                  >
                    {loading ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Processing...
                      </>
                    ) : (
                      <>
                        <Zap className="w-4 h-4 mr-2" />
                        {isAuthenticated ? 'Upgrade Now' : 'Login to Upgrade'}
                      </>
                    )}
                  </Button>
                )}
              </CardContent>
            </Card>
          ))}
        </div>

        {/* FAQ / Additional Info */}
        <div className="mt-16 text-center">
          <h2 className="text-xl font-semibold mb-4" style={{ fontFamily: 'Outfit, sans-serif' }}>
            Frequently Asked Questions
          </h2>
          <div className="grid md:grid-cols-2 gap-6 max-w-3xl mx-auto text-left">
            <Card className="border-0 shadow-md">
              <CardContent className="p-5">
                <h3 className="font-semibold mb-2">Can I cancel anytime?</h3>
                <p className="text-sm text-gray-600">Yes, you can cancel your subscription at any time. You'll continue to have access until the end of your billing period.</p>
              </CardContent>
            </Card>
            <Card className="border-0 shadow-md">
              <CardContent className="p-5">
                <h3 className="font-semibold mb-2">What happens to my scans?</h3>
                <p className="text-sm text-gray-600">All your analysis history is saved and accessible even on the free plan. Upgrade doesn't affect your existing data.</p>
              </CardContent>
            </Card>
            <Card className="border-0 shadow-md">
              <CardContent className="p-5">
                <h3 className="font-semibold mb-2">Do I get a refund?</h3>
                <p className="text-sm text-gray-600">We offer a 7-day money-back guarantee if you're not satisfied with Premium features.</p>
              </CardContent>
            </Card>
            <Card className="border-0 shadow-md">
              <CardContent className="p-5">
                <h3 className="font-semibold mb-2">Is my data secure?</h3>
                <p className="text-sm text-gray-600">Yes, we use industry-standard encryption. Your crop images and analysis data are never shared with third parties.</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Pricing;
