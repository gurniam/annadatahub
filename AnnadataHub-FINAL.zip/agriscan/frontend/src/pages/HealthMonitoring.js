import { useState, useEffect } from 'react';
import api from '../services/api';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { TrendingUp, Activity, Calendar } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Area, AreaChart } from 'recharts';
import Layout from '../components/Layout';

const HealthMonitoring = () => {
  const [healthData, setHealthData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [timeRange, setTimeRange] = useState('30');

  useEffect(() => {
    fetchHealthData();
  }, [timeRange]);

  const fetchHealthData = async () => {
    setLoading(true);
    try {
      const data = await api.getHealthData(parseInt(timeRange));
      setHealthData(data);
    } catch (error) {
      console.error('Error fetching health data:', error);
    } finally {
      setLoading(false);
    }
  };

  // Calculate stats
  const avgScore = healthData.length > 0 
    ? Math.round(healthData.reduce((sum, d) => sum + d.score, 0) / healthData.length)
    : 0;
  const totalScans = healthData.reduce((sum, d) => sum + d.scans, 0);
  const trend = healthData.length >= 2
    ? healthData[healthData.length - 1].score - healthData[0].score
    : 0;

  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-3 rounded-lg shadow-lg border border-gray-100">
          <p className="text-sm font-medium text-gray-900">{label}</p>
          <p className="text-sm text-green-600">Health: {payload[0].value}%</p>
          {payload[1] && <p className="text-sm text-blue-600">Scans: {payload[1].value}</p>}
        </div>
      );
    }
    return null;
  };

  return (
    <Layout>
      <div className="p-6 max-w-6xl mx-auto" data-testid="health-monitoring-page">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold text-[#0f172a]" style={{ fontFamily: 'Outfit, sans-serif' }}>
              Crop Health Monitoring
            </h1>
            <p className="text-gray-600 mt-1">Track your crop health trends over time</p>
          </div>
          <Select value={timeRange} onValueChange={setTimeRange}>
            <SelectTrigger className="w-40" data-testid="time-range-select">
              <Calendar className="w-4 h-4 mr-2" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7">Last 7 days</SelectItem>
              <SelectItem value="30">Last 30 days</SelectItem>
              <SelectItem value="90">Last 90 days</SelectItem>
              <SelectItem value="365">Last year</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <Card className="border-0 shadow-md" data-testid="avg-score-card">
            <CardContent className="p-5">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-gray-500">Average Health Score</span>
                <Activity className="w-5 h-5 text-green-600" />
              </div>
              <div className="text-3xl font-bold text-green-600" style={{ fontFamily: 'Outfit, sans-serif' }}>
                {avgScore}%
              </div>
              <p className="text-xs text-gray-500 mt-1">Based on healthy crop ratio</p>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-md" data-testid="total-scans-card">
            <CardContent className="p-5">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-gray-500">Total Scans</span>
                <Calendar className="w-5 h-5 text-blue-600" />
              </div>
              <div className="text-3xl font-bold text-blue-600" style={{ fontFamily: 'Outfit, sans-serif' }}>
                {totalScans}
              </div>
              <p className="text-xs text-gray-500 mt-1">In selected period</p>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-md" data-testid="trend-card">
            <CardContent className="p-5">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-gray-500">Health Trend</span>
                <TrendingUp className={`w-5 h-5 ${trend >= 0 ? 'text-green-600' : 'text-red-500'}`} />
              </div>
              <div className={`text-3xl font-bold ${trend >= 0 ? 'text-green-600' : 'text-red-500'}`} style={{ fontFamily: 'Outfit, sans-serif' }}>
                {trend >= 0 ? '+' : ''}{trend.toFixed(1)}%
              </div>
              <p className="text-xs text-gray-500 mt-1">Change over period</p>
            </CardContent>
          </Card>
        </div>

        {/* Main Chart */}
        <Card className="border-0 shadow-lg mb-6" data-testid="health-chart-card">
          <CardHeader>
            <CardTitle style={{ fontFamily: 'Outfit, sans-serif' }}>Health Score Over Time</CardTitle>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="h-80 flex items-center justify-center">
                <div className="loading-spinner"></div>
              </div>
            ) : healthData.length === 0 ? (
              <div className="h-80 flex flex-col items-center justify-center text-gray-500">
                <Activity className="w-16 h-16 text-gray-300 mb-4" />
                <p>No data available for the selected period</p>
                <p className="text-sm">Start scanning crops to see health trends</p>
              </div>
            ) : (
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={healthData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                    <defs>
                      <linearGradient id="colorScore" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#22c55e" stopOpacity={0.3}/>
                        <stop offset="95%" stopColor="#22c55e" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                    <XAxis 
                      dataKey="date" 
                      tick={{ fontSize: 12, fill: '#64748b' }}
                      tickFormatter={(date) => new Date(date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                    />
                    <YAxis 
                      tick={{ fontSize: 12, fill: '#64748b' }}
                      domain={[0, 100]}
                      tickFormatter={(value) => `${value}%`}
                    />
                    <Tooltip content={<CustomTooltip />} />
                    <Area 
                      type="monotone" 
                      dataKey="score" 
                      stroke="#22c55e" 
                      strokeWidth={2}
                      fillOpacity={1} 
                      fill="url(#colorScore)" 
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Scans Chart */}
        {healthData.length > 0 && (
          <Card className="border-0 shadow-lg" data-testid="scans-chart-card">
            <CardHeader>
              <CardTitle style={{ fontFamily: 'Outfit, sans-serif' }}>Daily Scan Activity</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={healthData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                    <XAxis 
                      dataKey="date" 
                      tick={{ fontSize: 12, fill: '#64748b' }}
                      tickFormatter={(date) => new Date(date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                    />
                    <YAxis tick={{ fontSize: 12, fill: '#64748b' }} />
                    <Tooltip content={<CustomTooltip />} />
                    <Line 
                      type="monotone" 
                      dataKey="scans" 
                      stroke="#3b82f6" 
                      strokeWidth={2}
                      dot={{ fill: '#3b82f6', strokeWidth: 2 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </Layout>
  );
};

export default HealthMonitoring;
