import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import api from '../services/api';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Progress } from '../components/ui/progress';
import { 
  Camera, 
  History, 
  TrendingUp, 
  AlertTriangle,
  CheckCircle2,
  ArrowRight,
  Leaf
} from 'lucide-react';
import Layout from '../components/Layout';

const Dashboard = () => {
  const { user } = useAuth();
  const [stats, setStats] = useState(null);
  const [recentHistory, setRecentHistory] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [statsData, historyData] = await Promise.all([
          api.getStats(),
          api.getHistory(5)
        ]);
        setStats(statsData);
        setRecentHistory(historyData);
      } catch (error) {
        console.error('Error fetching dashboard data:', error);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  const getSeverityBadge = (severity) => {
    const styles = {
      healthy: 'bg-green-100 text-green-700',
      mild: 'bg-blue-100 text-blue-700',
      moderate: 'bg-orange-100 text-orange-700',
      severe: 'bg-red-100 text-red-700',
      critical: 'bg-red-200 text-red-800'
    };
    return styles[severity] || 'bg-gray-100 text-gray-700';
  };

  const scansUsed = stats?.scans_this_month || 0;
  const scanLimit = stats?.scan_limit === -1 ? 'Unlimited' : stats?.scan_limit || 5;
  const isPremium = stats?.subscription_tier === 'premium';

  if (loading) {
    return (
      <Layout>
        <div className="flex items-center justify-center min-h-[60vh]">
          <div className="loading-spinner"></div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="p-6 max-w-6xl mx-auto" data-testid="dashboard-page">
        {/* Welcome Header */}
        <div className="mb-8">
          <h1 className="text-2xl md:text-3xl font-bold text-[#0f172a]" style={{ fontFamily: 'Outfit, sans-serif' }}>
            Welcome back, {user?.name?.split(' ')[0] || 'Farmer'}!
          </h1>
          <p className="text-gray-600 mt-1">Monitor your crop health and get AI-powered insights</p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {/* Scan Usage */}
          <Card className="border-0 shadow-md" data-testid="scan-usage-card">
            <CardContent className="p-5">
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm font-medium text-gray-500">Scans This Month</span>
                <Camera className="w-5 h-5 text-[#1a4d2e]" />
              </div>
              <div className="text-2xl font-bold text-[#0f172a]" style={{ fontFamily: 'Outfit, sans-serif' }}>
                {scansUsed} / {scanLimit}
              </div>
              {!isPremium && (
                <Progress value={(scansUsed / 5) * 100} className="h-2 mt-3" />
              )}
              {isPremium && (
                <span className="text-xs text-[#1a4d2e] font-medium">Premium - Unlimited</span>
              )}
            </CardContent>
          </Card>

          {/* Total Scans */}
          <Card className="border-0 shadow-md" data-testid="total-scans-card">
            <CardContent className="p-5">
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm font-medium text-gray-500">Total Analyses</span>
                <History className="w-5 h-5 text-[#1a4d2e]" />
              </div>
              <div className="text-2xl font-bold text-[#0f172a]" style={{ fontFamily: 'Outfit, sans-serif' }}>
                {stats?.total_scans || 0}
              </div>
              <span className="text-xs text-gray-500">All time</span>
            </CardContent>
          </Card>

          {/* Healthy Count */}
          <Card className="border-0 shadow-md" data-testid="healthy-count-card">
            <CardContent className="p-5">
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm font-medium text-gray-500">Healthy Crops</span>
                <CheckCircle2 className="w-5 h-5 text-green-600" />
              </div>
              <div className="text-2xl font-bold text-green-600" style={{ fontFamily: 'Outfit, sans-serif' }}>
                {stats?.severity_breakdown?.healthy || 0}
              </div>
              <span className="text-xs text-gray-500">No issues detected</span>
            </CardContent>
          </Card>

          {/* Issues Found */}
          <Card className="border-0 shadow-md" data-testid="issues-found-card">
            <CardContent className="p-5">
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm font-medium text-gray-500">Issues Found</span>
                <AlertTriangle className="w-5 h-5 text-orange-500" />
              </div>
              <div className="text-2xl font-bold text-orange-500" style={{ fontFamily: 'Outfit, sans-serif' }}>
                {(stats?.total_scans || 0) - (stats?.severity_breakdown?.healthy || 0)}
              </div>
              <span className="text-xs text-gray-500">Diseases detected</span>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Grid */}
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Quick Scan Card */}
          <Card className="lg:col-span-2 border-0 shadow-lg bg-gradient-to-br from-[#1a4d2e] to-[#0f3d1e] text-white" data-testid="quick-scan-card">
            <CardContent className="p-8">
              <div className="flex flex-col md:flex-row items-center gap-6">
                <div className="w-20 h-20 bg-[#f9d71c] rounded-full flex items-center justify-center flex-shrink-0">
                  <Camera className="w-10 h-10 text-[#0f172a]" />
                </div>
                <div className="text-center md:text-left flex-1">
                  <h2 className="text-xl md:text-2xl font-bold mb-2" style={{ fontFamily: 'Outfit, sans-serif' }}>
                    Scan Your Crops
                  </h2>
                  <p className="text-white/80 mb-4">
                    Take a photo or upload an image to get instant AI-powered disease diagnosis
                  </p>
                  <Link to="/scan">
                    <Button 
                      className="bg-[#f9d71c] hover:bg-[#e6c400] text-[#0f172a] font-bold rounded-full px-8"
                      data-testid="start-scan-btn"
                    >
                      Start Scan
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </Button>
                  </Link>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Subscription Status */}
          <Card className="border-0 shadow-lg" data-testid="subscription-card">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg" style={{ fontFamily: 'Outfit, sans-serif' }}>
                Your Plan
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-3 mb-4">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center ${isPremium ? 'bg-[#f9d71c]' : 'bg-gray-100'}`}>
                  <Leaf className={`w-5 h-5 ${isPremium ? 'text-[#0f172a]' : 'text-gray-600'}`} />
                </div>
                <div>
                  <p className="font-semibold capitalize">{stats?.subscription_tier || 'free'}</p>
                  <p className="text-sm text-gray-500">
                    {isPremium ? 'Unlimited access' : '5 scans/month'}
                  </p>
                </div>
              </div>
              {!isPremium && (
                <Link to="/pricing">
                  <Button variant="outline" className="w-full border-[#1a4d2e] text-[#1a4d2e] hover:bg-[#1a4d2e] hover:text-white" data-testid="upgrade-btn">
                    Upgrade to Premium
                  </Button>
                </Link>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Recent History */}
        <Card className="mt-6 border-0 shadow-lg" data-testid="recent-history-card">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle style={{ fontFamily: 'Outfit, sans-serif' }}>Recent Analyses</CardTitle>
            <Link to="/history">
              <Button variant="ghost" className="text-[#1a4d2e]" data-testid="view-all-history-btn">
                View All
                <ArrowRight className="w-4 h-4 ml-1" />
              </Button>
            </Link>
          </CardHeader>
          <CardContent>
            {recentHistory.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <Camera className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                <p>No analyses yet. Start by scanning a crop!</p>
              </div>
            ) : (
              <div className="space-y-3">
                {recentHistory.map((item) => (
                  <Link 
                    key={item.id} 
                    to={`/result/${item.id}`}
                    className="flex items-center justify-between p-4 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors"
                    data-testid={`history-item-${item.id}`}
                  >
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center">
                        <TrendingUp className="w-5 h-5 text-[#1a4d2e]" />
                      </div>
                      <div>
                        <p className="font-medium text-[#0f172a]">{item.disease_name}</p>
                        <p className="text-sm text-gray-500">{item.crop_type}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className={`px-3 py-1 rounded-full text-xs font-semibold ${getSeverityBadge(item.severity)}`}>
                        {item.severity}
                      </span>
                      <span className="text-sm text-gray-400">
                        {new Date(item.created_at).toLocaleDateString()}
                      </span>
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
};

export default Dashboard;
