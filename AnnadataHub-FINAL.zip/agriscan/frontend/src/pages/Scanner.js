import { useState, useRef, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../services/api';
import { Button } from '../components/ui/button';
import { Card, CardContent } from '../components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Camera, Upload, X, Loader2, Image as ImageIcon, RotateCcw } from 'lucide-react';
import { toast } from 'sonner';
import Layout from '../components/Layout';

const Scanner = () => {
  const navigate = useNavigate();
  const [mode, setMode] = useState('upload'); // 'upload' or 'camera'
  const [imagePreview, setImagePreview] = useState(null);
  const [imageBase64, setImageBase64] = useState(null);
  const [cropType, setCropType] = useState('');
  const [analyzing, setAnalyzing] = useState(false);
  const [cameraStream, setCameraStream] = useState(null);
  
  const fileInputRef = useRef(null);
  const videoRef = useRef(null);
  const canvasRef = useRef(null);

  const cropTypes = [
    'Wheat', 'Rice', 'Corn', 'Tomato', 'Potato', 'Apple', 'Grape',
    'Cotton', 'Soybean', 'Sugarcane', 'Coffee', 'Tea', 'Pepper',
    'Cucumber', 'Lettuce', 'Carrot', 'Onion', 'Other'
  ];

  const handleFileSelect = (e) => {
    const file = e.target.files?.[0];
    if (file) {
      if (!file.type.startsWith('image/')) {
        toast.error('Please select an image file');
        return;
      }
      if (file.size > 10 * 1024 * 1024) {
        toast.error('Image size must be less than 10MB');
        return;
      }
      
      const reader = new FileReader();
      reader.onload = (e) => {
        const base64 = e.target.result;
        setImagePreview(base64);
        // Remove the data URL prefix for the API
        setImageBase64(base64.split(',')[1]);
      };
      reader.readAsDataURL(file);
    }
  };

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment', width: { ideal: 1280 }, height: { ideal: 720 } }
      });
      setCameraStream(stream);
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
      setMode('camera');
    } catch (error) {
      console.error('Camera error:', error);
      toast.error('Could not access camera. Please check permissions.');
    }
  };

  const stopCamera = useCallback(() => {
    if (cameraStream) {
      cameraStream.getTracks().forEach(track => track.stop());
      setCameraStream(null);
    }
    setMode('upload');
  }, [cameraStream]);

  const capturePhoto = () => {
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      
      const ctx = canvas.getContext('2d');
      ctx.drawImage(video, 0, 0);
      
      const dataUrl = canvas.toDataURL('image/jpeg', 0.9);
      setImagePreview(dataUrl);
      setImageBase64(dataUrl.split(',')[1]);
      stopCamera();
    }
  };

  const clearImage = () => {
    setImagePreview(null);
    setImageBase64(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleAnalyze = async () => {
    if (!imageBase64) {
      toast.error('Please capture or upload an image first');
      return;
    }

    setAnalyzing(true);
    try {
      const result = await api.analyzeImage(imageBase64, cropType || null);
      toast.success('Analysis complete!');
      navigate(`/result/${result.id}`);
    } catch (error) {
      console.error('Analysis error:', error);
      if (error.response?.status === 403) {
        toast.error('Scan limit reached. Please upgrade to Premium for unlimited scans.');
        navigate('/pricing');
      } else {
        toast.error(error.response?.data?.detail || 'Analysis failed. Please try again.');
      }
    } finally {
      setAnalyzing(false);
    }
  };

  return (
    <Layout>
      <div className="p-6 max-w-2xl mx-auto" data-testid="scanner-page">
        <div className="text-center mb-8">
          <h1 className="text-2xl md:text-3xl font-bold text-[#0f172a]" style={{ fontFamily: 'Outfit, sans-serif' }}>
            Scan Your Crop
          </h1>
          <p className="text-gray-600 mt-2">
            Take a photo or upload an image for AI-powered disease analysis
          </p>
        </div>

        {/* Scanner Card */}
        <Card className="border-0 shadow-xl overflow-hidden" data-testid="scanner-card">
          <CardContent className="p-0">
            {/* Image Preview / Camera View */}
            <div className="relative aspect-square bg-gray-900">
              {mode === 'camera' && cameraStream ? (
                <>
                  <video
                    ref={videoRef}
                    autoPlay
                    playsInline
                    muted
                    className="w-full h-full object-cover"
                  />
                  <canvas ref={canvasRef} className="hidden" />
                  {/* Viewfinder corners */}
                  <div className="absolute inset-8 border-2 border-white/50 rounded-lg pointer-events-none">
                    <div className="absolute -top-1 -left-1 w-8 h-8 border-t-4 border-l-4 border-[#f9d71c] rounded-tl-lg"></div>
                    <div className="absolute -top-1 -right-1 w-8 h-8 border-t-4 border-r-4 border-[#f9d71c] rounded-tr-lg"></div>
                    <div className="absolute -bottom-1 -left-1 w-8 h-8 border-b-4 border-l-4 border-[#f9d71c] rounded-bl-lg"></div>
                    <div className="absolute -bottom-1 -right-1 w-8 h-8 border-b-4 border-r-4 border-[#f9d71c] rounded-br-lg"></div>
                  </div>
                  {/* Camera controls */}
                  <div className="absolute bottom-6 left-0 right-0 flex justify-center gap-4">
                    <Button
                      variant="outline"
                      size="icon"
                      className="w-12 h-12 rounded-full bg-white/20 border-white/40 text-white hover:bg-white/30"
                      onClick={stopCamera}
                      data-testid="cancel-camera-btn"
                    >
                      <X className="w-6 h-6" />
                    </Button>
                    <Button
                      size="icon"
                      className="w-16 h-16 rounded-full bg-[#f9d71c] hover:bg-[#e6c400] text-[#0f172a]"
                      onClick={capturePhoto}
                      data-testid="capture-photo-btn"
                    >
                      <Camera className="w-8 h-8" />
                    </Button>
                  </div>
                </>
              ) : imagePreview ? (
                <>
                  <img 
                    src={imagePreview} 
                    alt="Crop preview" 
                    className="w-full h-full object-contain bg-black"
                  />
                  <Button
                    variant="outline"
                    size="icon"
                    className="absolute top-4 right-4 rounded-full bg-white/90 hover:bg-white"
                    onClick={clearImage}
                    data-testid="clear-image-btn"
                  >
                    <X className="w-5 h-5" />
                  </Button>
                </>
              ) : (
                <div className="w-full h-full flex flex-col items-center justify-center text-white/60">
                  <ImageIcon className="w-16 h-16 mb-4" />
                  <p className="text-lg">No image selected</p>
                  <p className="text-sm mt-1">Upload or capture a photo below</p>
                </div>
              )}
            </div>

            {/* Controls */}
            <div className="p-6 space-y-4 bg-white">
              {!imagePreview && mode === 'upload' && (
                <div className="grid grid-cols-2 gap-3">
                  <input
                    type="file"
                    accept="image/*"
                    className="hidden"
                    ref={fileInputRef}
                    onChange={handleFileSelect}
                    data-testid="file-input"
                  />
                  <Button
                    variant="outline"
                    className="h-14 border-2 border-dashed border-gray-300 hover:border-[#1a4d2e] hover:bg-[#1a4d2e]/5"
                    onClick={() => fileInputRef.current?.click()}
                    data-testid="upload-btn"
                  >
                    <Upload className="w-5 h-5 mr-2" />
                    Upload Image
                  </Button>
                  <Button
                    variant="outline"
                    className="h-14 border-2 border-dashed border-gray-300 hover:border-[#1a4d2e] hover:bg-[#1a4d2e]/5"
                    onClick={startCamera}
                    data-testid="camera-btn"
                  >
                    <Camera className="w-5 h-5 mr-2" />
                    Use Camera
                  </Button>
                </div>
              )}

              {imagePreview && (
                <>
                  {/* Crop Type Selection */}
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-700">
                      Crop Type (optional)
                    </label>
                    <Select value={cropType} onValueChange={setCropType}>
                      <SelectTrigger className="w-full" data-testid="crop-type-select">
                        <SelectValue placeholder="Select crop type for better accuracy" />
                      </SelectTrigger>
                      <SelectContent>
                        {cropTypes.map((type) => (
                          <SelectItem key={type} value={type}>{type}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex gap-3">
                    <Button
                      variant="outline"
                      className="flex-1"
                      onClick={clearImage}
                      disabled={analyzing}
                      data-testid="retake-btn"
                    >
                      <RotateCcw className="w-4 h-4 mr-2" />
                      Retake
                    </Button>
                    <Button
                      className="flex-1 bg-[#1a4d2e] hover:bg-[#2d6a4f]"
                      onClick={handleAnalyze}
                      disabled={analyzing}
                      data-testid="analyze-btn"
                    >
                      {analyzing ? (
                        <>
                          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                          Analyzing...
                        </>
                      ) : (
                        'Analyze Crop'
                      )}
                    </Button>
                  </div>
                </>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Tips */}
        <div className="mt-6 p-4 bg-[#1a4d2e]/5 rounded-xl">
          <h3 className="font-semibold text-[#1a4d2e] mb-2" style={{ fontFamily: 'Outfit, sans-serif' }}>
            Tips for Best Results
          </h3>
          <ul className="text-sm text-gray-600 space-y-1">
            <li>• Take a clear, well-lit photo of the affected area</li>
            <li>• Focus on leaves, stems, or fruits showing symptoms</li>
            <li>• Include both healthy and affected parts if possible</li>
            <li>• Avoid blurry or distant shots</li>
          </ul>
        </div>
      </div>
    </Layout>
  );
};

export default Scanner;
