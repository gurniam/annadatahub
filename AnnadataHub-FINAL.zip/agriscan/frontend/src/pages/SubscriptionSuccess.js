import { useState, useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import api from '../services/api';
import { Card, CardContent } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { CheckCircle2, Loader2, Crown, ArrowRight } from 'lucide-react';
import { toast } from 'sonner';

const SubscriptionSuccess = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { refreshUser } = useAuth();
  const [status, setStatus] = useState('checking'); // checking, success, error

  useEffect(() => {
    const sessionId = searchParams.get('session_id');
    if (sessionId) {
      pollPaymentStatus(sessionId);
    } else {
      setStatus('error');
    }
  }, [searchParams]);

  const pollPaymentStatus = async (sessionId, attempts = 0) => {
    if (attempts >= 5) {
      setStatus('error');
      toast.error('Payment verification timed out');
      return;
    }

    try {
      const response = await api.getCheckoutStatus(sessionId);
      if (response.payment_status === 'paid') {
        setStatus('success');
        refreshUser();
        toast.success('Welcome to AgriScan Premium!');
      } else if (response.status === 'expired') {
        setStatus('error');
      } else {
        setTimeout(() => pollPaymentStatus(sessionId, attempts + 1), 2000);
      }
    } catch (error) {
      console.error('Error checking status:', error);
      setStatus('error');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-green-900 to-green-950 flex items-center justify-center p-6">
      <Card className="w-full max-w-md" data-testid="subscription-success-card">
        <CardContent className="p-8 text-center">
          {status === 'checking' && (
            <>
              <Loader2 className="w-16 h-16 mx-auto text-[#1a4d2e] animate-spin mb-4" />
              <h1 className="text-2xl font-bold text-[#0f172a] mb-2" style={{ fontFamily: 'Outfit, sans-serif' }}>
                Verifying Payment...
              </h1>
              <p className="text-gray-600">Please wait while we confirm your subscription</p>
            </>
          )}

          {status === 'success' && (
            <>
              <div className="w-20 h-20 mx-auto bg-green-100 rounded-full flex items-center justify-center mb-6">
                <CheckCircle2 className="w-10 h-10 text-green-600" />
              </div>
              <div className="inline-flex items-center gap-2 bg-[#f9d71c] text-[#0f172a] px-4 py-2 rounded-full mb-4">
                <Crown className="w-4 h-4" />
                <span className="font-bold text-sm">PREMIUM</span>
              </div>
              <h1 className="text-2xl font-bold text-[#0f172a] mb-2" style={{ fontFamily: 'Outfit, sans-serif' }}>
                Welcome to Premium!
              </h1>
              <p className="text-gray-600 mb-6">
                You now have unlimited access to all AgriScan AI features
              </p>
              <div className="space-y-3">
                <Button
                  className="w-full bg-[#1a4d2e] hover:bg-[#2d6a4f]"
                  onClick={() => navigate('/scan')}
                  data-testid="start-scanning-btn"
                >
                  Start Scanning
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
                <Button
                  variant="outline"
                  className="w-full"
                  onClick={() => navigate('/dashboard')}
                  data-testid="go-to-dashboard-btn"
                >
                  Go to Dashboard
                </Button>
              </div>
            </>
          )}

          {status === 'error' && (
            <>
              <div className="w-20 h-20 mx-auto bg-red-100 rounded-full flex items-center justify-center mb-6">
                <span className="text-4xl">😕</span>
              </div>
              <h1 className="text-2xl font-bold text-[#0f172a] mb-2" style={{ fontFamily: 'Outfit, sans-serif' }}>
                Something Went Wrong
              </h1>
              <p className="text-gray-600 mb-6">
                We couldn't verify your payment. If you were charged, please contact support.
              </p>
              <Button
                className="w-full bg-[#1a4d2e] hover:bg-[#2d6a4f]"
                onClick={() => navigate('/pricing')}
                data-testid="try-again-btn"
              >
                Try Again
              </Button>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default SubscriptionSuccess;
