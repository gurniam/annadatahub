import { useState } from 'react';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Input } from '../components/ui/input';
import { 
  Package, 
  Thermometer, 
  Droplets, 
  Wind,
  Clock,
  TrendingUp,
  AlertTriangle,
  Loader2,
  CheckCircle2,
  Calendar
} from 'lucide-react';
import { toast } from 'sonner';
import Layout from '../components/Layout';

const LANGUAGES = {
  "en": "English",
  "hi": "Hindi (हिंदी)",
  "bn": "Bengali (বাংলা)",
  "te": "Telugu (తెలుగు)",
  "mr": "Marathi (मराठी)",
  "ta": "Tamil (தமிழ்)",
  "gu": "Gujarati (ગુજરાતી)",
  "kn": "Kannada (ಕನ್ನಡ)",
  "ml": "Malayalam (മലയാളം)",
  "pa": "Punjabi (ਪੰਜਾਬੀ)",
  "or": "Odia (ଓଡ଼ିଆ)",
  "as": "Assamese (অসমীয়া)",
  "ur": "Urdu (اردو)"
};

const CROP_TYPES = [
  'Wheat', 'Rice', 'Corn', 'Tomato', 'Potato', 'Onion', 'Garlic',
  'Apple', 'Mango', 'Banana', 'Grapes', 'Orange', 'Carrot', 'Cabbage',
  'Cauliflower', 'Spinach', 'Groundnut', 'Soybean', 'Cotton', 'Sugarcane'
];

const PostHarvest = () => {
  const [loading, setLoading] = useState(false);
  const [advice, setAdvice] = useState(null);
  const [formData, setFormData] = useState({
    crop_type: '',
    harvest_date: '',
    storage_conditions: '',
    quantity: '',
    language: 'en'
  });

  const handleSubmit = async () => {
    if (!formData.crop_type) {
      toast.error('Please select a crop type');
      return;
    }

    setLoading(true);
    try {
      const response = await fetch(`${process.env.REACT_APP_BACKEND_URL}/api/postharvest/advice`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('agriscan_token')}`
        },
        body: JSON.stringify(formData)
      });
      
      if (!response.ok) throw new Error('Failed to get advice');
      
      const data = await response.json();
      setAdvice(data);
      toast.success('Post-harvest advice generated!');
    } catch (error) {
      console.error('Error:', error);
      toast.error('Failed to get advice. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Layout>
      <div className="p-6 max-w-4xl mx-auto" data-testid="postharvest-page">
        <div className="mb-8">
          <h1 className="text-2xl md:text-3xl font-bold text-[#0f172a]" style={{ fontFamily: 'Outfit, sans-serif' }}>
            Post-Harvest Loss Prevention
          </h1>
          <p className="text-gray-600 mt-1">Maximize your harvest value with proper storage and handling</p>
        </div>

        {/* Stats Banner */}
        <Card className="border-0 shadow-md bg-gradient-to-r from-orange-500 to-red-500 text-white mb-6">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <AlertTriangle className="w-8 h-8" />
              <div>
                <p className="font-bold text-lg">30-40% of crops are lost post-harvest</p>
                <p className="text-white/80 text-sm">Proper storage can reduce losses by up to 90%</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Input Form */}
        <Card className="border-0 shadow-lg mb-6" data-testid="postharvest-form">
          <CardHeader>
            <CardTitle style={{ fontFamily: 'Outfit, sans-serif' }}>Tell us about your harvest</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-gray-700 mb-1 block">Crop Type *</label>
                <Select value={formData.crop_type} onValueChange={(v) => setFormData({...formData, crop_type: v})}>
                  <SelectTrigger data-testid="crop-select">
                    <SelectValue placeholder="Select crop" />
                  </SelectTrigger>
                  <SelectContent>
                    {CROP_TYPES.map(crop => (
                      <SelectItem key={crop} value={crop}>{crop}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700 mb-1 block">Language</label>
                <Select value={formData.language} onValueChange={(v) => setFormData({...formData, language: v})}>
                  <SelectTrigger data-testid="language-select">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {Object.entries(LANGUAGES).map(([code, name]) => (
                      <SelectItem key={code} value={code}>{name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700 mb-1 block">Harvest Date</label>
                <Input 
                  type="date"
                  value={formData.harvest_date}
                  onChange={(e) => setFormData({...formData, harvest_date: e.target.value})}
                  data-testid="harvest-date-input"
                />
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700 mb-1 block">Quantity</label>
                <Input 
                  placeholder="e.g., 500 kg, 10 quintals"
                  value={formData.quantity}
                  onChange={(e) => setFormData({...formData, quantity: e.target.value})}
                  data-testid="quantity-input"
                />
              </div>
            </div>
            <div>
              <label className="text-sm font-medium text-gray-700 mb-1 block">Current Storage Conditions</label>
              <Input 
                placeholder="Describe your current storage setup"
                value={formData.storage_conditions}
                onChange={(e) => setFormData({...formData, storage_conditions: e.target.value})}
                data-testid="storage-input"
              />
            </div>
            <Button 
              className="w-full bg-[#1a4d2e] hover:bg-[#2d6a4f]"
              onClick={handleSubmit}
              disabled={loading}
              data-testid="get-advice-btn"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Generating Advice...
                </>
              ) : (
                <>
                  <Package className="w-4 h-4 mr-2" />
                  Get Post-Harvest Advice
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        {/* Advice Results */}
        {advice && (
          <div className="space-y-4 fade-in" data-testid="advice-results">
            {/* Optimal Conditions */}
            <Card className="border-0 shadow-lg">
              <CardHeader className="bg-blue-50">
                <CardTitle className="flex items-center gap-2" style={{ fontFamily: 'Outfit, sans-serif' }}>
                  <Thermometer className="w-5 h-5 text-blue-600" />
                  Optimal Storage Conditions
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                <div className="grid grid-cols-3 gap-4">
                  <div className="text-center p-4 bg-gray-50 rounded-xl">
                    <Thermometer className="w-8 h-8 text-red-500 mx-auto mb-2" />
                    <p className="text-sm text-gray-500">Temperature</p>
                    <p className="font-bold text-lg">{advice.optimal_conditions?.temperature || 'N/A'}</p>
                  </div>
                  <div className="text-center p-4 bg-gray-50 rounded-xl">
                    <Droplets className="w-8 h-8 text-blue-500 mx-auto mb-2" />
                    <p className="text-sm text-gray-500">Humidity</p>
                    <p className="font-bold text-lg">{advice.optimal_conditions?.humidity || 'N/A'}</p>
                  </div>
                  <div className="text-center p-4 bg-gray-50 rounded-xl">
                    <Wind className="w-8 h-8 text-green-500 mx-auto mb-2" />
                    <p className="text-sm text-gray-500">Ventilation</p>
                    <p className="font-bold text-lg text-sm">{advice.optimal_conditions?.ventilation || 'N/A'}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Shelf Life & Market Timing */}
            <div className="grid md:grid-cols-2 gap-4">
              <Card className="border-0 shadow-lg">
                <CardContent className="p-6">
                  <div className="flex items-center gap-3 mb-3">
                    <Clock className="w-8 h-8 text-purple-500" />
                    <div>
                      <p className="text-sm text-gray-500">Expected Shelf Life</p>
                      <p className="font-bold text-lg">{advice.shelf_life}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card className="border-0 shadow-lg">
                <CardContent className="p-6">
                  <div className="flex items-center gap-3 mb-3">
                    <TrendingUp className="w-8 h-8 text-green-500" />
                    <div>
                      <p className="text-sm text-gray-500">Best Time to Sell</p>
                      <p className="font-bold text-lg">{advice.market_timing}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Storage Tips */}
            {advice.storage_tips?.length > 0 && (
              <Card className="border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2" style={{ fontFamily: 'Outfit, sans-serif' }}>
                    <Package className="w-5 h-5 text-[#1a4d2e]" />
                    Storage Tips
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2">
                    {advice.storage_tips.map((tip, index) => (
                      <li key={index} className="flex items-start gap-2">
                        <CheckCircle2 className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
                        <span className="text-gray-700">{tip}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            )}

            {/* Handling Guidelines */}
            {advice.handling_guidelines?.length > 0 && (
              <Card className="border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2" style={{ fontFamily: 'Outfit, sans-serif' }}>
                    Handling Guidelines
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2">
                    {advice.handling_guidelines.map((guideline, index) => (
                      <li key={index} className="flex items-start gap-2">
                        <CheckCircle2 className="w-5 h-5 text-blue-500 flex-shrink-0 mt-0.5" />
                        <span className="text-gray-700">{guideline}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            )}

            {/* Loss Prevention Tips */}
            {advice.loss_prevention_tips?.length > 0 && (
              <Card className="border-0 shadow-lg border-l-4 border-l-orange-500">
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2" style={{ fontFamily: 'Outfit, sans-serif' }}>
                    <AlertTriangle className="w-5 h-5 text-orange-500" />
                    Loss Prevention Tips
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2">
                    {advice.loss_prevention_tips.map((tip, index) => (
                      <li key={index} className="flex items-start gap-2">
                        <span className="w-6 h-6 bg-orange-100 text-orange-600 rounded-full flex items-center justify-center flex-shrink-0 text-sm font-medium">
                          {index + 1}
                        </span>
                        <span className="text-gray-700">{tip}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            )}
          </div>
        )}
      </div>
    </Layout>
  );
};

export default PostHarvest;
