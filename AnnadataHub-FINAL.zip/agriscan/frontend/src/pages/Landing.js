import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Button } from '../components/ui/button';
import { Card, CardContent } from '../components/ui/card';
import { 
  Leaf, 
  Camera, 
  History, 
  Users, 
  Shield, 
  Zap, 
  CheckCircle2,
  ArrowRight,
  Star
} from 'lucide-react';

const Landing = () => {
  const { isAuthenticated } = useAuth();

  const features = [
    {
      icon: <Camera className="w-6 h-6" />,
      title: 'AI-Powered Analysis',
      description: 'Instant disease detection using advanced Claude AI vision technology'
    },
    {
      icon: <Shield className="w-6 h-6" />,
      title: 'Treatment Plans',
      description: 'Get detailed treatment recommendations and prevention tips'
    },
    {
      icon: <History className="w-6 h-6" />,
      title: '12+ Languages',
      description: 'Personalized advice in Hindi, Bengali, Tamil & 9 more regional languages'
    },
    {
      icon: <Users className="w-6 h-6" />,
      title: 'Early Warning Network',
      description: 'Community-powered pest & disease alerts for your region'
    }
  ];

  const testimonials = [
    {
      name: 'John Miller',
      role: 'Corn Farmer, Iowa',
      content: 'AgriScan helped me identify leaf blight early and saved 30% of my harvest.',
      rating: 5
    },
    {
      name: 'Sarah Chen',
      role: 'Vineyard Owner, Napa',
      content: 'The treatment recommendations are spot-on. My vines have never been healthier.',
      rating: 5
    },
    {
      name: 'Miguel Santos',
      role: 'Organic Farm, Texas',
      content: 'Essential tool for any modern farmer. The community is incredibly helpful.',
      rating: 5
    }
  ];

  return (
    <div className="min-h-screen bg-[#f8fafc]">
      {/* Navigation */}
      <nav className="bg-white/80 backdrop-blur-md border-b border-gray-100 sticky top-0 z-50">
        <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2" data-testid="landing-logo">
            <div className="w-10 h-10 bg-[#1a4d2e] rounded-xl flex items-center justify-center">
              <Leaf className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold text-[#1a4d2e]" style={{ fontFamily: 'Outfit, sans-serif' }}>
              AgriScan AI
            </span>
          </Link>
          <div className="flex items-center gap-4">
            {isAuthenticated ? (
              <Link to="/dashboard">
                <Button className="bg-[#1a4d2e] hover:bg-[#2d6a4f] rounded-full px-6" data-testid="go-to-dashboard-btn">
                  Go to Dashboard
                </Button>
              </Link>
            ) : (
              <>
                <Link to="/login">
                  <Button variant="ghost" className="text-[#1a4d2e]" data-testid="landing-login-btn">
                    Login
                  </Button>
                </Link>
                <Link to="/register">
                  <Button className="bg-[#1a4d2e] hover:bg-[#2d6a4f] rounded-full px-6" data-testid="landing-signup-btn">
                    Get Started
                  </Button>
                </Link>
              </>
            )}
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="bg-gradient-to-b from-[#14532d] to-[#0f3d1e] text-white py-20 md:py-32 relative overflow-hidden">
        <div className="absolute inset-0 opacity-5" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 400 400' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E")`
        }}></div>
        <div className="max-w-6xl mx-auto px-6 text-center relative">
          <div className="inline-flex items-center gap-2 bg-white/10 rounded-full px-4 py-2 mb-6">
            <Zap className="w-4 h-4 text-[#f9d71c]" />
            <span className="text-sm font-medium">Powered by Claude AI Vision</span>
          </div>
          <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight" style={{ fontFamily: 'Outfit, sans-serif' }}>
            Protect Your Crops with<br />
            <span className="text-[#f9d71c]">AI-Powered</span> Disease Detection
          </h1>
          <p className="text-lg md:text-xl text-white/80 max-w-2xl mx-auto mb-10">
            Snap a photo of your crops and get instant diagnosis, treatment plans, 
            and prevention tips from our advanced AI system.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to={isAuthenticated ? "/scan" : "/register"}>
              <Button 
                className="bg-[#f9d71c] hover:bg-[#e6c400] text-[#0f172a] font-bold px-8 py-6 text-lg rounded-full shadow-lg shadow-[#f9d71c]/30"
                data-testid="hero-scan-btn"
              >
                <Camera className="w-5 h-5 mr-2" />
                Start Scanning Free
              </Button>
            </Link>
            <Link to="/pricing">
              <Button 
                variant="outline" 
                className="border-white/30 text-white hover:bg-white/10 px-8 py-6 text-lg rounded-full"
                data-testid="hero-pricing-btn"
              >
                View Pricing
              </Button>
            </Link>
          </div>
          <p className="text-sm text-white/60 mt-4">5 free scans per month. No credit card required.</p>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-[#0f172a] mb-4" style={{ fontFamily: 'Outfit, sans-serif' }}>
              Everything You Need for Healthy Crops
            </h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Our comprehensive platform combines AI technology with expert agricultural knowledge
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, index) => (
              <Card key={index} className="border-0 shadow-lg hover:shadow-xl transition-shadow" data-testid={`feature-card-${index}`}>
                <CardContent className="p-6">
                  <div className="w-12 h-12 bg-[#1a4d2e]/10 rounded-xl flex items-center justify-center text-[#1a4d2e] mb-4">
                    {feature.icon}
                  </div>
                  <h3 className="text-lg font-semibold mb-2" style={{ fontFamily: 'Outfit, sans-serif' }}>
                    {feature.title}
                  </h3>
                  <p className="text-gray-600 text-sm">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20 px-6 bg-white">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-[#0f172a] mb-4" style={{ fontFamily: 'Outfit, sans-serif' }}>
              How It Works
            </h2>
            <p className="text-gray-600">Three simple steps to healthier crops</p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              { step: '1', title: 'Capture', desc: 'Take a photo of your affected crop using your phone camera' },
              { step: '2', title: 'Analyze', desc: 'Our AI instantly analyzes the image for diseases and issues' },
              { step: '3', title: 'Treat', desc: 'Get detailed treatment plans and prevention tips' }
            ].map((item, index) => (
              <div key={index} className="text-center" data-testid={`how-it-works-${index}`}>
                <div className="w-16 h-16 bg-[#1a4d2e] text-white rounded-full flex items-center justify-center text-2xl font-bold mx-auto mb-4" style={{ fontFamily: 'Outfit, sans-serif' }}>
                  {item.step}
                </div>
                <h3 className="text-xl font-semibold mb-2" style={{ fontFamily: 'Outfit, sans-serif' }}>{item.title}</h3>
                <p className="text-gray-600">{item.desc}</p>
                {index < 2 && (
                  <ArrowRight className="w-6 h-6 text-gray-300 mx-auto mt-4 hidden md:block rotate-0 md:rotate-0" />
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-[#0f172a] mb-4" style={{ fontFamily: 'Outfit, sans-serif' }}>
              Trusted by Farmers Worldwide
            </h2>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="border-0 shadow-lg" data-testid={`testimonial-${index}`}>
                <CardContent className="p-6">
                  <div className="flex gap-1 mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-[#f9d71c] text-[#f9d71c]" />
                    ))}
                  </div>
                  <p className="text-gray-700 mb-4">"{testimonial.content}"</p>
                  <div>
                    <p className="font-semibold">{testimonial.name}</p>
                    <p className="text-sm text-gray-500">{testimonial.role}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-6 bg-[#1a4d2e]">
        <div className="max-w-4xl mx-auto text-center text-white">
          <h2 className="text-3xl md:text-4xl font-bold mb-4" style={{ fontFamily: 'Outfit, sans-serif' }}>
            Ready to Protect Your Crops?
          </h2>
          <p className="text-white/80 mb-8 text-lg">
            Join thousands of farmers using AgriScan AI to keep their crops healthy
          </p>
          <Link to={isAuthenticated ? "/scan" : "/register"}>
            <Button 
              className="bg-[#f9d71c] hover:bg-[#e6c400] text-[#0f172a] font-bold px-10 py-6 text-lg rounded-full"
              data-testid="cta-signup-btn"
            >
              Get Started Free
              <ArrowRight className="w-5 h-5 ml-2" />
            </Button>
          </Link>
          <div className="flex items-center justify-center gap-6 mt-8 text-sm text-white/60">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4" />
              <span>5 free scans/month</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4" />
              <span>No credit card</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4" />
              <span>Cancel anytime</span>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#0f172a] text-white py-12 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-center gap-6">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-[#1a4d2e] rounded-lg flex items-center justify-center">
                <Leaf className="w-4 h-4 text-white" />
              </div>
              <span className="font-bold" style={{ fontFamily: 'Outfit, sans-serif' }}>AgriScan AI</span>
            </div>
            <div className="flex gap-8 text-sm text-gray-400">
              <Link to="/pricing" className="hover:text-white">Pricing</Link>
              <Link to="/community" className="hover:text-white">Community</Link>
              <a href="mailto:support@agriscan.ai" className="hover:text-white">Support</a>
            </div>
            <p className="text-sm text-gray-500">© 2026 AgriScan AI. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Landing;
