import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import api from '../services/api';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { 
  History as HistoryIcon, 
  Trash2, 
  ChevronRight,
  Search,
  Filter,
  Calendar
} from 'lucide-react';
import { Input } from '../components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { toast } from 'sonner';
import Layout from '../components/Layout';

const History = () => {
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [severityFilter, setSeverityFilter] = useState('all');

  useEffect(() => {
    fetchHistory();
  }, []);

  const fetchHistory = async () => {
    try {
      const data = await api.getHistory(100);
      setHistory(data);
    } catch (error) {
      console.error('Error fetching history:', error);
      toast.error('Could not load history');
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id, e) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (!window.confirm('Are you sure you want to delete this analysis?')) return;
    
    try {
      await api.deleteAnalysis(id);
      setHistory(history.filter(item => item.id !== id));
      toast.success('Analysis deleted');
    } catch (error) {
      toast.error('Could not delete analysis');
    }
  };

  const getSeverityBadge = (severity) => {
    const styles = {
      healthy: 'bg-green-100 text-green-700',
      mild: 'bg-blue-100 text-blue-700',
      moderate: 'bg-orange-100 text-orange-700',
      severe: 'bg-red-100 text-red-700',
      critical: 'bg-red-200 text-red-800'
    };
    return styles[severity] || 'bg-gray-100 text-gray-700';
  };

  const filteredHistory = history.filter(item => {
    const matchesSearch = 
      item.disease_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.crop_type.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesSeverity = severityFilter === 'all' || item.severity === severityFilter;
    return matchesSearch && matchesSeverity;
  });

  if (loading) {
    return (
      <Layout>
        <div className="flex items-center justify-center min-h-[60vh]">
          <div className="loading-spinner"></div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="p-6 max-w-4xl mx-auto" data-testid="history-page">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold text-[#0f172a]" style={{ fontFamily: 'Outfit, sans-serif' }}>
              Analysis History
            </h1>
            <p className="text-gray-600 mt-1">View all your past crop analyses</p>
          </div>
          <div className="flex items-center gap-2 text-sm text-gray-500">
            <HistoryIcon className="w-4 h-4" />
            <span>{history.length} analyses</span>
          </div>
        </div>

        {/* Filters */}
        <Card className="border-0 shadow-md mb-6" data-testid="filters-card">
          <CardContent className="p-4">
            <div className="flex flex-col sm:flex-row gap-3">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <Input
                  placeholder="Search by disease or crop..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-9"
                  data-testid="search-input"
                />
              </div>
              <Select value={severityFilter} onValueChange={setSeverityFilter}>
                <SelectTrigger className="w-full sm:w-48" data-testid="severity-filter">
                  <Filter className="w-4 h-4 mr-2" />
                  <SelectValue placeholder="Filter by severity" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Severities</SelectItem>
                  <SelectItem value="healthy">Healthy</SelectItem>
                  <SelectItem value="mild">Mild</SelectItem>
                  <SelectItem value="moderate">Moderate</SelectItem>
                  <SelectItem value="severe">Severe</SelectItem>
                  <SelectItem value="critical">Critical</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* History List */}
        {filteredHistory.length === 0 ? (
          <Card className="border-0 shadow-lg" data-testid="empty-state">
            <CardContent className="p-12 text-center">
              <HistoryIcon className="w-16 h-16 mx-auto text-gray-300 mb-4" />
              <h2 className="text-xl font-semibold text-gray-700 mb-2" style={{ fontFamily: 'Outfit, sans-serif' }}>
                {history.length === 0 ? 'No analyses yet' : 'No results found'}
              </h2>
              <p className="text-gray-500 mb-6">
                {history.length === 0 
                  ? 'Start by scanning a crop to see your history here'
                  : 'Try adjusting your search or filter criteria'
                }
              </p>
              {history.length === 0 && (
                <Link to="/scan">
                  <Button className="bg-[#1a4d2e] hover:bg-[#2d6a4f]" data-testid="start-scanning-btn">
                    Start Scanning
                  </Button>
                </Link>
              )}
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-3">
            {filteredHistory.map((item) => (
              <Link 
                key={item.id} 
                to={`/result/${item.id}`}
                data-testid={`history-item-${item.id}`}
              >
                <Card className="border-0 shadow-md hover:shadow-lg transition-all cursor-pointer mb-3">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4 flex-1">
                        <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${getSeverityBadge(item.severity).split(' ')[0]}`}>
                          <span className="text-lg font-bold" style={{ fontFamily: 'Outfit, sans-serif' }}>
                            {item.crop_type.charAt(0)}
                          </span>
                        </div>
                        <div className="flex-1 min-w-0">
                          <h3 className="font-semibold text-[#0f172a] truncate" style={{ fontFamily: 'Outfit, sans-serif' }}>
                            {item.disease_name}
                          </h3>
                          <div className="flex items-center gap-3 text-sm text-gray-500">
                            <span>{item.crop_type}</span>
                            <span className="flex items-center gap-1">
                              <Calendar className="w-3 h-3" />
                              {new Date(item.created_at).toLocaleDateString()}
                            </span>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className={`px-3 py-1 rounded-full text-xs font-semibold capitalize hidden sm:block ${getSeverityBadge(item.severity)}`}>
                          {item.severity}
                        </span>
                        <span className="text-sm text-gray-400">
                          {Math.round(item.confidence * 100)}%
                        </span>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="text-gray-400 hover:text-red-500"
                          onClick={(e) => handleDelete(item.id, e)}
                          data-testid={`delete-btn-${item.id}`}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                        <ChevronRight className="w-5 h-5 text-gray-300" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        )}
      </div>
    </Layout>
  );
};

export default History;
