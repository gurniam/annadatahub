import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import api from '../services/api';
import { Button } from '../components/ui/button';
import { Card, CardContent } from '../components/ui/card';
import { Input } from '../components/ui/input';
import { Badge } from '../components/ui/badge';
import { ArrowLeft, Heart, MessageCircle, Send, User } from 'lucide-react';
import { toast } from 'sonner';
import Layout from '../components/Layout';

const PostDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { isAuthenticated } = useAuth();
  const [post, setPost] = useState(null);
  const [comments, setComments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [newComment, setNewComment] = useState('');
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    fetchPostAndComments();
  }, [id]);

  const fetchPostAndComments = async () => {
    try {
      const [postData, commentsData] = await Promise.all([
        api.getPost(id),
        api.getComments(id)
      ]);
      setPost(postData);
      setComments(commentsData);
    } catch (error) {
      console.error('Error fetching post:', error);
      toast.error('Could not load post');
      navigate('/community');
    } finally {
      setLoading(false);
    }
  };

  const handleLike = async () => {
    if (!isAuthenticated) {
      toast.error('Please login to like posts');
      return;
    }

    try {
      const result = await api.likePost(id);
      setPost(prev => ({
        ...prev,
        likes: result.liked ? prev.likes + 1 : prev.likes - 1
      }));
    } catch (error) {
      toast.error('Failed to like post');
    }
  };

  const handleComment = async () => {
    if (!isAuthenticated) {
      toast.error('Please login to comment');
      return;
    }
    if (!newComment.trim()) return;

    setSubmitting(true);
    try {
      const comment = await api.createComment(id, newComment);
      setComments([...comments, comment]);
      setNewComment('');
      setPost(prev => ({ ...prev, comments_count: prev.comments_count + 1 }));
      toast.success('Comment added!');
    } catch (error) {
      toast.error('Failed to add comment');
    } finally {
      setSubmitting(false);
    }
  };

  const getInitials = (name) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
  };

  if (loading) {
    return (
      <Layout>
        <div className="flex items-center justify-center min-h-[60vh]">
          <div className="loading-spinner"></div>
        </div>
      </Layout>
    );
  }

  if (!post) {
    return (
      <Layout>
        <div className="p-6 text-center">
          <p>Post not found</p>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="p-6 max-w-3xl mx-auto" data-testid="post-detail-page">
        {/* Back Button */}
        <Button
          variant="ghost"
          onClick={() => navigate('/community')}
          className="mb-4 text-gray-600"
          data-testid="back-to-community-btn"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Community
        </Button>

        {/* Post Card */}
        <Card className="border-0 shadow-lg mb-6" data-testid="post-card">
          <CardContent className="p-6">
            {/* Author */}
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 rounded-full bg-[#1a4d2e] text-white flex items-center justify-center font-semibold">
                {getInitials(post.user_name)}
              </div>
              <div>
                <p className="font-semibold text-[#0f172a]">{post.user_name}</p>
                <p className="text-sm text-gray-500">
                  {new Date(post.created_at).toLocaleDateString('en-US', {
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric'
                  })}
                </p>
              </div>
            </div>

            {/* Title */}
            <h1 className="text-2xl font-bold text-[#0f172a] mb-4" style={{ fontFamily: 'Outfit, sans-serif' }}>
              {post.title}
            </h1>

            {/* Content */}
            <div className="prose prose-sm max-w-none mb-4">
              <p className="text-gray-700 whitespace-pre-wrap">{post.content}</p>
            </div>

            {/* Tags */}
            {post.tags?.length > 0 && (
              <div className="flex flex-wrap gap-2 mb-4">
                {post.tags.map(tag => (
                  <Badge key={tag} variant="secondary">#{tag}</Badge>
                ))}
              </div>
            )}

            {/* Actions */}
            <div className="flex items-center gap-6 pt-4 border-t border-gray-100">
              <button
                className="flex items-center gap-2 text-gray-600 hover:text-red-500 transition-colors"
                onClick={handleLike}
                data-testid="like-post-btn"
              >
                <Heart className="w-5 h-5" />
                <span>{post.likes} likes</span>
              </button>
              <span className="flex items-center gap-2 text-gray-600">
                <MessageCircle className="w-5 h-5" />
                <span>{post.comments_count} comments</span>
              </span>
            </div>
          </CardContent>
        </Card>

        {/* Comments Section */}
        <Card className="border-0 shadow-lg" data-testid="comments-section">
          <CardContent className="p-6">
            <h2 className="text-lg font-semibold mb-4" style={{ fontFamily: 'Outfit, sans-serif' }}>
              Comments ({comments.length})
            </h2>

            {/* Comment Input */}
            {isAuthenticated ? (
              <div className="flex gap-3 mb-6">
                <Input
                  placeholder="Add a comment..."
                  value={newComment}
                  onChange={(e) => setNewComment(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleComment()}
                  data-testid="comment-input"
                />
                <Button 
                  onClick={handleComment}
                  disabled={submitting || !newComment.trim()}
                  className="bg-[#1a4d2e] hover:bg-[#2d6a4f]"
                  data-testid="submit-comment-btn"
                >
                  <Send className="w-4 h-4" />
                </Button>
              </div>
            ) : (
              <p className="text-gray-500 text-sm mb-6">
                Please <a href="/login" className="text-[#1a4d2e] font-medium">login</a> to comment
              </p>
            )}

            {/* Comments List */}
            {comments.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <MessageCircle className="w-12 h-12 mx-auto text-gray-300 mb-2" />
                <p>No comments yet. Be the first to comment!</p>
              </div>
            ) : (
              <div className="space-y-4">
                {comments.map(comment => (
                  <div key={comment.id} className="flex gap-3 p-4 bg-gray-50 rounded-xl" data-testid={`comment-${comment.id}`}>
                    <div className="w-8 h-8 rounded-full bg-gray-300 text-gray-600 flex items-center justify-center flex-shrink-0 text-sm font-medium">
                      {getInitials(comment.user_name)}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-medium text-[#0f172a]">{comment.user_name}</span>
                        <span className="text-xs text-gray-400">
                          {new Date(comment.created_at).toLocaleDateString()}
                        </span>
                      </div>
                      <p className="text-gray-700 text-sm">{comment.content}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
};

export default PostDetail;
