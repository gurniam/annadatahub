import { useAuth } from '../context/AuthContext';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { 
  User, 
  Mail, 
  Calendar, 
  Crown, 
  LogOut,
  Settings,
  Shield
} from 'lucide-react';
import { useNavigate, Link } from 'react-router-dom';
import { toast } from 'sonner';
import Layout from '../components/Layout';

const Profile = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    toast.success('Logged out successfully');
    navigate('/');
  };

  const isPremium = user?.subscription_tier === 'premium';

  return (
    <Layout>
      <div className="p-6 max-w-2xl mx-auto" data-testid="profile-page">
        <h1 className="text-2xl md:text-3xl font-bold text-[#0f172a] mb-8" style={{ fontFamily: 'Outfit, sans-serif' }}>
          Your Profile
        </h1>

        {/* Profile Card */}
        <Card className="border-0 shadow-lg mb-6" data-testid="profile-card">
          <CardContent className="p-6">
            <div className="flex items-start gap-4">
              <div className="w-16 h-16 bg-[#1a4d2e] rounded-full flex items-center justify-center text-white text-xl font-bold">
                {user?.name?.charAt(0).toUpperCase() || 'U'}
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <h2 className="text-xl font-semibold text-[#0f172a]" style={{ fontFamily: 'Outfit, sans-serif' }}>
                    {user?.name}
                  </h2>
                  {isPremium && (
                    <Badge className="bg-[#f9d71c] text-[#0f172a]">
                      <Crown className="w-3 h-3 mr-1" />
                      Premium
                    </Badge>
                  )}
                </div>
                <p className="text-gray-500 flex items-center gap-2">
                  <Mail className="w-4 h-4" />
                  {user?.email}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Account Details */}
        <Card className="border-0 shadow-lg mb-6" data-testid="account-details-card">
          <CardHeader>
            <CardTitle className="text-lg" style={{ fontFamily: 'Outfit, sans-serif' }}>
              Account Details
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <div className="flex items-center gap-3">
                <User className="w-5 h-5 text-gray-500" />
                <div>
                  <p className="text-sm text-gray-500">Name</p>
                  <p className="font-medium">{user?.name}</p>
                </div>
              </div>
            </div>
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <div className="flex items-center gap-3">
                <Mail className="w-5 h-5 text-gray-500" />
                <div>
                  <p className="text-sm text-gray-500">Email</p>
                  <p className="font-medium">{user?.email}</p>
                </div>
              </div>
            </div>
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <div className="flex items-center gap-3">
                <Calendar className="w-5 h-5 text-gray-500" />
                <div>
                  <p className="text-sm text-gray-500">Member Since</p>
                  <p className="font-medium">
                    {user?.created_at 
                      ? new Date(user.created_at).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })
                      : 'N/A'
                    }
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Subscription Card */}
        <Card className="border-0 shadow-lg mb-6" data-testid="subscription-status-card">
          <CardHeader>
            <CardTitle className="text-lg" style={{ fontFamily: 'Outfit, sans-serif' }}>
              Subscription
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between p-4 bg-gradient-to-r from-[#1a4d2e]/10 to-[#1a4d2e]/5 rounded-xl">
              <div className="flex items-center gap-3">
                <div className={`w-12 h-12 rounded-full flex items-center justify-center ${isPremium ? 'bg-[#f9d71c]' : 'bg-gray-100'}`}>
                  {isPremium ? (
                    <Crown className="w-6 h-6 text-[#0f172a]" />
                  ) : (
                    <Shield className="w-6 h-6 text-gray-500" />
                  )}
                </div>
                <div>
                  <p className="font-semibold text-[#0f172a] capitalize">
                    {user?.subscription_tier || 'Free'} Plan
                  </p>
                  <p className="text-sm text-gray-500">
                    {isPremium ? 'Unlimited scans' : `${5 - (user?.scans_this_month || 0)} scans remaining this month`}
                  </p>
                </div>
              </div>
              {!isPremium && (
                <Link to="/pricing">
                  <Button className="bg-[#1a4d2e] hover:bg-[#2d6a4f]" data-testid="upgrade-btn">
                    Upgrade
                  </Button>
                </Link>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Actions */}
        <div className="space-y-3">
          <Button
            variant="outline"
            className="w-full justify-start text-red-600 border-red-200 hover:bg-red-50 hover:text-red-700"
            onClick={handleLogout}
            data-testid="logout-btn"
          >
            <LogOut className="w-4 h-4 mr-2" />
            Sign Out
          </Button>
        </div>
      </div>
    </Layout>
  );
};

export default Profile;
