# AgriScan AI — Full Deployment Guide
## GoDaddy Domain + Firebase Frontend + Google Cloud Run Backend

---

## Prerequisites

Install these tools first:
- [Node.js](https://nodejs.org) (v18+)
- [Google Cloud CLI](https://cloud.google.com/sdk/docs/install)
- [Firebase CLI](https://firebase.google.com/docs/cli): `npm install -g firebase-tools`

---

## Part 1 — MongoDB Atlas (Database)

1. Go to https://www.mongodb.com/atlas and create a free account
2. Create a free cluster (M0 tier — free forever)
3. Click **Connect** → **Drivers** → copy the connection string
4. It looks like: `mongodb+srv://username:password@cluster0.xxxxx.mongodb.net/agriscan`
5. **Save this string** — you'll need it in Part 2

---

## Part 2 — Deploy Backend to Google Cloud Run

### 2.1 Setup Google Cloud
```bash
# Login
gcloud auth login

# Create a new project (or use existing)
gcloud projects create agriscan-ai-prod --name="AgriScan AI"
gcloud config set project agriscan-ai-prod

# Enable billing at https://console.cloud.google.com/billing
# Enable required APIs
gcloud services enable run.googleapis.com
gcloud services enable cloudbuild.googleapis.com
```

### 2.2 Deploy the Backend
```bash
cd backend

# Deploy (replace ALL values below with your real keys)
gcloud run deploy agriscan-backend \
  --source . \
  --region us-central1 \
  --allow-unauthenticated \
  --port 8080 \
  --set-env-vars \
MONGO_URL="mongodb+srv://user:pass@cluster0.xxxxx.mongodb.net/agriscan",\
DB_NAME="agriscan",\
EMERGENT_LLM_KEY="sk-emergent-xxxx",\
STRIPE_API_KEY="sk_live_xxxx",\
JWT_SECRET_KEY="your-super-secret-key-change-this",\
CORS_ORIGINS="https://yourdomain.com"
```

### 2.3 Get Your Backend URL
After deploy, you'll see something like:
```
Service URL: https://agriscan-backend-abcd1234-uc.a.run.app
```
**Copy this URL** — you need it in Part 3.

---

## Part 3 — Deploy Frontend to Firebase

### 3.1 Update Backend URL
Open `frontend/.env.production` and replace with your real Cloud Run URL:
```
REACT_APP_BACKEND_URL=https://agriscan-backend-abcd1234-uc.a.run.app
```

### 3.2 Build the React App
```bash
cd frontend
npm install
npm run build
```

### 3.3 Setup Firebase
```bash
# Login to Firebase
firebase login

# Create project at https://console.firebase.google.com
# Then link it (replace agriscan-ai with your Firebase project ID)
# Edit .firebaserc and set your project ID

# Deploy
firebase deploy
```

You'll get a URL like: `https://agriscan-ai.web.app`

---

## Part 4 — Connect Your GoDaddy Domain

### 4.1 Add Custom Domain in Firebase
1. Go to [Firebase Console](https://console.firebase.google.com)
2. Select your project → **Hosting** → **Add custom domain**
3. Enter your domain: `yourdomain.com`
4. Firebase will show you **two A records** like:
   ```
   Type: A    Name: @    Value: 151.101.1.195
   Type: A    Name: @    Value: 151.101.65.195
   ```
5. Also add `www` redirect if you want

### 4.2 Add DNS Records in GoDaddy
1. Log in to [GoDaddy](https://godaddy.com)
2. Go to **My Products** → find your domain → click **DNS**
3. Delete any existing A records for `@`
4. Click **Add** → add each A record Firebase gave you:
   ```
   Type: A
   Name: @
   Value: 151.101.1.195   (first IP from Firebase)
   TTL: 600

   Type: A
   Name: @
   Value: 151.101.65.195  (second IP from Firebase)
   TTL: 600
   ```
5. For `www` subdomain, add a CNAME:
   ```
   Type: CNAME
   Name: www
   Value: yourdomain.com
   TTL: 600
   ```

### 4.3 Wait for DNS Propagation
- Usually takes **10–30 minutes**, sometimes up to 24 hours
- Firebase automatically provisions your **free SSL certificate**
- Check status in Firebase Console → Hosting

---

## Part 5 — Update CORS for Your Domain

Once your domain is live, update the backend's CORS setting.
In Google Cloud Console → Cloud Run → agriscan-backend → Edit:

Change `CORS_ORIGINS` to:
```
https://yourdomain.com,https://www.yourdomain.com
```

Redeploy:
```bash
gcloud run deploy agriscan-backend \
  --source . \
  --region us-central1 \
  --allow-unauthenticated \
  --set-env-vars CORS_ORIGINS="https://yourdomain.com,https://www.yourdomain.com"
```

---

## Checklist

- [ ] MongoDB Atlas cluster created, connection string saved
- [ ] Google Cloud project created and billing enabled
- [ ] Backend deployed to Cloud Run, URL copied
- [ ] Frontend `.env.production` updated with backend URL
- [ ] React app built (`npm run build`)
- [ ] Firebase project created
- [ ] Frontend deployed to Firebase
- [ ] GoDaddy A records added
- [ ] Firebase custom domain verified
- [ ] SSL certificate active (green lock)
- [ ] CORS updated with real domain

---

## Estimated Costs

| Service | Cost |
|---|---|
| Google Cloud Run | ~Free (first 2M requests/month free) |
| Firebase Hosting | Free (10GB storage, 360MB/day transfer) |
| MongoDB Atlas | Free (512MB) |
| GoDaddy Domain | Already paid ✅ |
| **Total** | **~$0/month to start** |

---

## Need Help?

- Cloud Run logs: `gcloud run logs read agriscan-backend --region us-central1`
- Firebase logs: Firebase Console → Hosting
- MongoDB: Atlas Dashboard → Monitoring
