# 🌾 AnnadataHub — Complete Developer Instructions
## Read this fully before starting

---

## 👋 About This Project
AnnadataHub is an AI-powered farming platform for Indian farmers.
- Owner: annadattahub@gmail.com
- Language: Works in 11 Indian languages
- Payment: Razorpay (Indian payment gateway)
- AI: Claude AI (Anthropic)

---

## 📦 FILES IN THIS ZIP

| File | What it is |
|------|-----------|
| /backend/ | Python FastAPI server — deploy on Render.com |
| /frontend/ | React.js website — deploy on Vercel.com |
| /frontend/public/pricing.html | Razorpay payment page |
| /frontend/public/legal.html | Refund, Terms & Privacy policies |
| /frontend/public/farmer-tools.html | Mandi Prices, Weather, Govt Schemes |
| /frontend/public/crop-tools.html | Crop Calendar, Fertilizer Calculator |
| /frontend/public/power-tools.html | Voice, Profit, Soil, News, Chat |
| /frontend/public/admin.html | Owner's admin control panel |

---

## 🔑 CREDENTIALS OWNER WILL GIVE YOU

Before starting, ask owner for:
1. Claude AI API Key (starts with sk-ant-)
2. GoDaddy domain name
3. Razorpay Key ID (may come later)

---

## 🚀 DEPLOYMENT — STEP BY STEP

---

### STEP 1 — MongoDB Atlas (Free Database)
1. Go to https://www.mongodb.com/atlas
2. Sign up free
3. Create cluster → choose M0 Free tier
4. Set username + password — write these down!
5. Go to Network Access → Add IP Address → Allow from anywhere (0.0.0.0/0)
6. Click Connect → Drivers → copy the connection string
   Looks like: mongodb+srv://username:password@cluster.xxxxx.mongodb.net/annadatahub
7. SAVE THIS STRING — you need it in Step 2

---

### STEP 2 — Deploy Backend on Render.com (Free)
1. Create GitHub account if you don't have one
2. Upload the /backend folder to a new GitHub repository
3. Go to https://render.com → Sign up free with GitHub
4. Click New → Web Service → Select your repository
5. Set these settings:
   - Name: annadatahub-backend
   - Root Directory: backend
   - Runtime: Python 3
   - Build Command: pip install -r requirements.txt
   - Start Command: uvicorn server:app --host 0.0.0.0 --port 8080

6. Click Environment → Add these variables ONE BY ONE:

   MONGO_URL          → (MongoDB connection string from Step 1)
   DB_NAME            → annadatahub
   EMERGENT_LLM_KEY   → (Claude AI key from owner — starts with sk-ant-)
   JWT_SECRET_KEY     → annadatahub-india-secret-2024
   STRIPE_API_KEY     → sk_test_placeholder
   CORS_ORIGINS       → https://www.YOURDOMAIN.com

7. Click Create Web Service
8. Wait 3-5 minutes for deployment
9. COPY the URL shown — example: https://annadatahub-backend.onrender.com
10. SAVE THIS URL — you need it in Step 3

---

### STEP 3 — Deploy Frontend on Vercel.com (Free)
1. Upload the /frontend folder to GitHub (same or different repo)
2. Go to https://vercel.com → Sign up free with GitHub
3. Click Add New Project → Import your frontend repo
4. Set Framework Preset: Create React App
5. Root Directory: frontend
6. Click Environment Variables → Add:

   REACT_APP_BACKEND_URL → (Render URL from Step 2)

7. Click Deploy
8. Wait 2 minutes
9. You get a URL like: https://annadatahub.vercel.app
10. TEST IT — open the URL, check if website loads

---

### STEP 4 — Connect GoDaddy Domain
1. In Vercel → your project → Settings → Domains
2. Click Add Domain → type the owner's domain name
3. Vercel shows you DNS records like:
   Type: A    Name: @     Value: 76.76.21.21
4. Go to GoDaddy → My Products → Domain → DNS → Manage DNS
5. DELETE any existing A records with name @
6. ADD the A records Vercel gave you
7. ADD CNAME record:
   Type: CNAME    Name: www    Value: cname.vercel-dns.com
8. Click Save
9. Back in Vercel → click Verify
10. Wait 15-30 minutes
11. SSL certificate activates automatically ✅

---

### STEP 5 — Update CORS for Domain
After domain is connected, go to Render.com
→ Your service → Environment → Update CORS_ORIGINS:
   CORS_ORIGINS → https://www.YOURDOMAIN.com,https://YOURDOMAIN.com
Redeploy the service.

---

### STEP 6 — Update Legal Page
Open /frontend/public/legal.html
Find and replace:
- "+91 XXXXX XXXXX" → owner's real WhatsApp number
- "[Your City]" → owner's real city name
Save and upload to Vercel.

---

### STEP 7 — Add Navigation Links
In the main website, add links to all pages in the footer and/or menu:
- /pricing.html → Pricing & Payment
- /legal.html → Legal Policies
- /farmer-tools.html → Farmer Tools
- /crop-tools.html → Crop Calendar & Fertilizer
- /power-tools.html → Voice & More Tools
- /admin.html → Admin (keep this one private — don't show in menu)

---

### STEP 8 — Add Razorpay Key (Owner will give later)
Open /frontend/public/pricing.html
Find this line:
   const RAZORPAY_KEY = "rzp_test_YourKeyHere";
Replace YourKeyHere with the owner's real Razorpay Key ID
Save and redeploy.

---

## ✅ TESTING CHECKLIST
Test ALL of these before handing over to owner:

### Website Basics
☐ https://www.YOURDOMAIN.com loads
☐ Green padlock (SSL) shows in browser
☐ Website loads on Android phone
☐ Register new account works
☐ Login works
☐ Logout works
☐ Forgot password works

### All Pages Load
☐ /pricing.html loads correctly
☐ /legal.html loads with 3 tabs
☐ /farmer-tools.html loads
☐ /crop-tools.html loads
☐ /power-tools.html loads
☐ /admin.html loads and login works

### AI Features (need EMERGENT_LLM_KEY)
☐ Upload crop photo → AI shows disease result
☐ Crop Calendar → generates weekly plan
☐ Fertilizer Calculator → shows quantities
☐ Mandi Prices → shows crop prices
☐ Weather → shows forecast
☐ Government Schemes → shows schemes
☐ Voice Assistant → answers question
☐ Profit Calculator → shows profit/loss
☐ Agriculture News → loads news
☐ Farmer Chat → messages work

### Admin Panel
☐ /admin.html login works
☐ Dashboard shows stats
☐ Farmers list loads
☐ Payments list loads
☐ Send notification works
☐ Analytics loads

### Mobile Testing
☐ All pages look good on mobile
☐ Buttons are easy to tap with finger
☐ No text is too small to read
☐ Images load properly

---

## ⚠️ COMMON PROBLEMS & SOLUTIONS

| Problem | Solution |
|---------|---------|
| Backend not starting | Check ALL environment variables are added correctly |
| AI not working | Double check EMERGENT_LLM_KEY is correct — no spaces |
| CORS error in browser | Add domain to CORS_ORIGINS in Render and redeploy |
| Domain not connecting | Wait 30 minutes. Check DNS records are exactly as Vercel said |
| Database error | In MongoDB Atlas → Network Access → Allow 0.0.0.0/0 |
| White screen on website | Check browser console for errors. Check REACT_APP_BACKEND_URL |
| Admin login not working | Password is admin123 — owner should change this after launch |

---

## 📱 IMPORTANT NOTES

1. Most Indian farmers use Android phones — test on Android first
2. Test on slow internet (3G) — app should load in under 5 seconds
3. All prices are in ₹ INR — do not change to USD
4. Do NOT put the /admin.html link in the main navigation
5. Do NOT upload API keys to GitHub — add them only in Render dashboard
6. If Render goes to sleep (free tier), it takes 30 seconds to wake up — this is normal

---

## 💰 ALL SERVICES ARE FREE

| Service | Website | Cost |
|---------|---------|------|
| Database | mongodb.com/atlas | Free |
| Backend | render.com | Free |
| Frontend | vercel.com | Free |
| SSL Certificate | Auto from Vercel | Free |
| Domain | Owner has it on GoDaddy | Already paid |

---

## 📞 OWNER CONTACT

Email: annadattahub@gmail.com
App: AnnadataHub — AI Farming Platform for India 🇮🇳

Please send the owner:
1. Live website URL
2. Admin panel URL and login details
3. Backend URL (Render)
4. MongoDB Atlas login
5. Brief note on how to restart if website goes down

