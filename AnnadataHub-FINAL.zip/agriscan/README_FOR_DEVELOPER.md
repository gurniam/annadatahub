# 🌾 AnnadataHub — Developer Instructions
## India Launch Package

---

## About This Project
AnnadataHub is an AI-powered crop disease detection platform for Indian farmers.
- Frontend: React.js
- Backend: Python FastAPI
- Database: MongoDB
- AI: Claude AI (Anthropic)
- Payments: Razorpay

---

## ✅ WHAT YOU HAVE TO DO (Step by Step)

### STEP 1 — Create Free Database (MongoDB Atlas)
1. Go to https://www.mongodb.com/atlas
2. Sign up free
3. Create a free cluster (M0 tier)
4. Set username and password
5. Click Connect → Drivers → copy the connection string
6. Looks like: mongodb+srv://username:password@cluster.xxxxx.mongodb.net/annadatahub

---

### STEP 2 — Deploy Backend (Render.com)
1. Go to https://render.com → Sign up free
2. Create a new Web Service
3. Upload the /backend folder (via GitHub)
4. Settings:
   - Root Directory: backend
   - Runtime: Python 3
   - Start Command: uvicorn server:app --host 0.0.0.0 --port 8080
5. Add these Environment Variables:

   MONGO_URL          = (MongoDB connection string from Step 1)
   DB_NAME            = annadatahub
   EMERGENT_LLM_KEY   = (PROVIDED BY OWNER — Claude AI key)
   JWT_SECRET_KEY     = annadatahub-secret-2024
   STRIPE_API_KEY     = sk_test_placeholder
   CORS_ORIGINS       = https://www.YOURDOMAIN.com

6. Click Deploy → wait 3-5 minutes
7. Copy the backend URL (looks like: https://annadatahub-backend.onrender.com)

---

### STEP 3 — Deploy Frontend (Vercel.com)
1. Go to https://vercel.com → Sign up free
2. Import the /frontend folder (via GitHub)
3. Add Environment Variable:
   REACT_APP_BACKEND_URL = (backend URL from Step 2)
4. Click Deploy → wait 2 minutes
5. Copy the frontend URL

---

### STEP 4 — Connect GoDaddy Domain
1. In Vercel → Project → Settings → Domains
2. Add the owner's domain name
3. Vercel gives you 2 A record values
4. Go to GoDaddy → DNS → Delete old A records
5. Add the 2 new A records from Vercel
6. Add CNAME: www → cname.vercel-dns.com
7. Wait 15-30 minutes → site is live!

---

### STEP 5 — Upload Extra Pages
These files are in /frontend/public/ — make sure they are accessible at:
- www.DOMAIN.com/pricing.html  → Razorpay payment page
- www.DOMAIN.com/legal.html    → Terms, Refund & Privacy policy

---

### STEP 6 — Update Legal Page
Open /frontend/public/legal.html and replace:
- "+91 XXXXX XXXXX" → owner's real WhatsApp number
- "[Your City]" → owner's city name

---

### STEP 7 — Test Everything
Before handing over, please test:
☐ Website loads on the domain
☐ Register/Login works
☐ Crop scanner uploads a photo
☐ AI gives a disease result
☐ Pricing page loads
☐ Legal page loads
☐ Mobile view looks good

---

## 📋 CREDENTIALS OWNER WILL PROVIDE
- GoDaddy domain name
- EMERGENT_LLM_KEY (Claude AI API key)
- Razorpay Key ID (after Razorpay approval)
- WhatsApp number for legal page

---

## 📞 CONTACT
- Email: annadattahub@gmail.com
- All questions → contact the owner directly

---

## 💰 ALL SERVICES ARE FREE TIER
- Render.com → Free
- Vercel.com → Free
- MongoDB Atlas → Free
- Domain → Owner already has it
- SSL Certificate → Auto (free)

---

## ⚠️ IMPORTANT NOTES
1. This is for Indian users — keep everything in INR
2. Razorpay is the payment gateway (not Stripe)
3. The owner will add Razorpay key after Razorpay approves the account
4. Do NOT share the API key with anyone
5. Test on mobile — most Indian farmers use phones


---

## NEW FEATURES ADDED

### farmer-tools.html
Located at: /frontend/public/farmer-tools.html
Make it accessible at: www.DOMAIN.com/farmer-tools.html

This page has 3 powerful features:
1. Live Mandi Prices — AI powered, all states, all crops
2. Weather & Farm Alerts — location based, crop specific
3. Government Schemes — eligibility checker, PM-KISAN etc

All features work in 11 regional languages including Hindi, Bengali, Tamil etc.
Add a link to this page in the main navigation menu.
